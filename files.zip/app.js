/* ═══════════════════════════════════════════
   NAVIGATION
═══════════════════════════════════════════ */
function goPage(id){
  if(id==='admin'){
    if(!currentUser){toast('Connectez-vous d\'abord','err');return;}
    if(currentUser.role!=='admin'){toast('Accès non autorisé','err');goPage('home');return;}
  }
  if(!currentUser && !['home','energybot','forum','leaderboard','certs'].includes(id)){return;}
  // Sync Firebase à chaque changement de page
  if(fbReady && id!=='admin') checkForUpdates().catch(e=>console.warn(e));
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('on'));
  document.getElementById('pg-'+id).classList.add('on');
  document.querySelectorAll('.np').forEach(b=>b.classList.remove('on'));
  const idx={home:0,courses:1,exams:2,leaderboard:3,certs:4,energybot:5,boutique:6,forum:7,planning:8};
  const navLinks=document.querySelectorAll('#nav-links .np');
  if(idx[id]!==undefined && navLinks[idx[id]]) navLinks[idx[id]].classList.add('on');
  document.getElementById('notif-panel').classList.remove('open');
  // Sauvegarder la page courante
  try{ localStorage.setItem('erse_current_page', id); }catch(e){}
  // Force reflow pour les pages avec layout grid/flex hauteur fixe
  if(['energybot','admin','forum'].includes(id)){
    const pg=document.getElementById('pg-'+id);
    if(pg){void pg.offsetHeight;}
  }
  const renders={home:renderHome,planning:()=>initPlanning(),forum:()=>{loadForumData();renderForum(FORUM.posts);},courses:()=>{
    const userLvl=getUserLevel();
    const tabs=document.querySelectorAll('#lvl-tabs .tab');
    const targetTab=tabs[userLvl-1]||tabs[0];
    filterLevel(userLvl,targetTab);
    renderLevelBadge();
  },exams:()=>{ examActive=false; document.getElementById('quiz-wrap').style.display='none'; document.getElementById('exam-list-wrap').style.display=''; renderExamList(); renderLevelBadge(); },leaderboard:()=>refreshLeaderboard(),certs:renderCerts,profile:renderProfile,boutique:()=>loadShop(),energybot:()=>{
    const keyBtn=document.getElementById('eb-key-btn');
    if(keyBtn) keyBtn.style.display=currentUser?.role==='admin'?'':'none';
    // Recalcul explicite du layout EnergyBot
    const layout=document.querySelector('.eb-layout');
    const main=document.querySelector('.eb-main');
    if(layout&&main){
      layout.style.height='';
      main.style.height='';
      requestAnimationFrame(()=>{
        layout.style.height='calc(100vh - 62px)';
        main.style.height='calc(100vh - 62px)';
      });
    }
  },admin:()=>{
    // Recalcul layout admin
    const adminMain=document.querySelector('.admin-main');
    if(adminMain){void adminMain.offsetHeight;}
    adminTab('dashboard',document.querySelector('.ani'));
  }};
  if(renders[id]) renders[id]();
}

function showMoreMenu(){
  const m = document.getElementById('mobile-more-menu');
  if(m) m.style.display = m.style.display==='none'?'block':'none';
}
function hideMoreMenu(){
  const m = document.getElementById('mobile-more-menu');
  if(m) m.style.display='none';
}
function toggleMobile(){document.getElementById('mobile-menu').classList.toggle('open');}

/* ═══════════════════════════════════════════
   DARK MODE
═══════════════════════════════════════════ */
function toggleDark(){
  darkMode=!darkMode;
  document.documentElement.setAttribute('data-theme',darkMode?'dark':'light');
  document.getElementById('dm-btn').textContent=darkMode?'☀️ Light':'🌙 Dark';
}

/* ═══════════════════════════════════════════
   HOME
═══════════════════════════════════════════ */
function renderHome(){
  const total=DB.subjects.reduce((a,s)=>a+s.docs,0);
  const totalCerts=DB.students.reduce((a,s)=>a+s.certs,0)+(currentUser?DB.certificates.length:0);
  document.getElementById('stats-bar').innerHTML=[
    {n:DB.subjects.filter(s=>s.active).length,l:'Matières actives'},
    {n:DB.exams.length,l:'Examens disponibles'},
    {n:total,l:'Documents gratuits'},
    {n:totalCerts,l:'Certificats délivrés'},
  ].map(s=>`<div class="si"><div class="sn">${s.n}</div><div class="sl">${s.l}</div></div>`).join('');
  document.getElementById('home-cards').innerHTML=DB.subjects.filter(s=>s.active).slice(0,6).map(cardHtml).join('');
  // Animer les compteurs hero
  animateCounter('hero-count-1', DB.students.length);
  animateCounter('hero-count-2', DB.students.reduce((a,s)=>a+s.certs,0)+DB.certificates.length);
  animateCounter('hero-count-3', DB.subjects.reduce((a,s)=>a+s.docs,0));
  animateCounter('hero-count-4', DB.exams.length);
  const top3=[...DB.students].sort((a,b)=>b.avgScore-a.avgScore).slice(0,3);
  const medals=['🥇','🥈','🥉'];
  document.getElementById('home-top3').innerHTML=top3.map((s,i)=>`
    <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:14px;padding:1.1rem;display:flex;align-items:center;gap:12px;">
      <span style="font-size:22px;">${medals[i]}</span>
      <div class="avatar" style="background:${s.color}22;color:${s.color};font-size:11px;font-weight:600;">${s.initials}</div>
      <div style="flex:1;"><div style="font-size:13px;font-weight:500;">${s.name}</div><div style="font-size:11px;color:var(--muted);">${s.certs} certs · L${s.level}</div></div>
      <div style="font-family:var(--font-display);font-size:17px;font-weight:600;color:var(--gold-d);">${s.avgScore}%</div>
    </div>`).join('');
  // Afficher les examens disponibles avec minuteur de session
  renderExamCountdowns();
}

let countdownInterval = null;

function renderExamCountdowns(){
  const wrap = document.getElementById('home-exam-countdowns');
  if(!wrap) return;
  if(DB.exams.length===0){ wrap.innerHTML=''; return; }

  // Afficher les 3 premiers examens avec un compteur de session
  const examsToShow = DB.exams.slice(0,3);
  wrap.innerHTML = `
    <div style="margin-top:1.5rem;">
      <div style="font-family:var(--font-display);font-size:17px;font-weight:600;color:var(--b9);margin-bottom:1rem;">⏳ Examens disponibles</div>
      <div style="display:flex;flex-direction:column;gap:10px;">
        ${examsToShow.map(e=>{
          const s=DB.subjects.find(x=>x.id===e.subjectId||parseInt(x.id)===parseInt(e.subjectId));
          const mins = e.questions.length * 2;
          return `
            <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:14px;padding:1rem 1.2rem;display:flex;align-items:center;justify-content:space-between;gap:12px;">
              <div style="display:flex;align-items:center;gap:10px;">
                <div style="font-size:24px;">${s?s.icon:'📝'}</div>
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--text);">${e.title||s?.name||'Examen'}</div>
                  <div style="font-size:11px;color:var(--muted);">📋 ${e.questions.length} questions · ⏱ ${mins} min · ${e.difficulty==='Avancé'||e.difficulty==='hard'?'🔴 Avancé':e.difficulty==='Intermédiaire'||e.difficulty==='medium'?'🟡 Intermédiaire':'🟢 Débutant'}</div>
                </div>
              </div>
              <button class="btn-start" onclick="goPage('exams')" style="white-space:nowrap;font-size:12px;padding:7px 14px;">Commencer →</button>
            </div>`;
        }).join('')}
        ${DB.exams.length>3?`<div style="text-align:center;"><button onclick="goPage('exams')" style="font-size:13px;color:var(--gold-d);background:none;border:none;cursor:pointer;font-family:var(--font-body);">Voir tous les examens (${DB.exams.length}) →</button></div>`:''}
      </div>
    </div>`;
}

function cardHtml(s){
  const ex=DB.exams.find(e=>parseInt(e.subjectId)===parseInt(s.id)||String(e.subjectId)===String(s.id));
  const examCount=DB.exams.filter(e=>parseInt(e.subjectId)===parseInt(s.id)||String(e.subjectId)===String(s.id)).length;
  return `<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
      <div class="c-ico">${s.icon}</div><span class="pill-lvl l${s.level}p">L${s.level}</span>
    </div>
    <div class="c-ttl">${s.name}</div>
    <div class="c-sub">${s.docs} documents${s.desc?' · '+s.desc:''}${examCount?' · '+examCount+' examen(s)':''}</div>
    <div class="c-acts">
      <button class="bs bs-dl" onclick="goPage('courses')">📂 Documents</button>
      ${ex?`<button class="bs bs-ex" onclick="goPage('exams')">✏ Examen</button>`:''}
    </div>
  </div>`;
}

/* ═══════════════════════════════════════════
   COURSES + PDF
═══════════════════════════════════════════ */
/* ═══════════════════════════════════════════
   SYSTÈME DE NIVEAUX
═══════════════════════════════════════════ */
function getUserLevel(){ return currentUser ? (currentUser.level||1) : 1; }

function getLevelProgress(){
  const lvl = getUserLevel();
  const examsForLevel = DB.exams.filter(e=>{
    const s = DB.subjects.find(x=>x.id===e.subjectId);
    return s && s.level===lvl;
  });
  if(examsForLevel.length===0) return {total:0,done:0,avg:0,canPass:false};
  const results = DB.examResults || [];
  let totalScore = 0, done = 0;
  examsForLevel.forEach(e=>{
    const r = results.find(r=>r.examId===e.id);
    if(r){ totalScore += r.score; done++; }
  });
  const avg = done>0 ? Math.round(totalScore/examsForLevel.length) : 0;
  const canPass = done>0 && avg>=80;
  return {total:examsForLevel.length, done, avg, canPass};
}

function checkLevelAccess(targetLevel){
  const userLevel = getUserLevel();
  if(currentUser && currentUser.role==='admin') return true;
  return targetLevel <= userLevel;
}

async function requestLevelUp(){
  const lvl = getUserLevel();
  const prog = getLevelProgress();
  if(!prog.canPass){
    toast(`Score insuffisant : ${prog.avg}/100. Il faut 80/100 de moyenne.`,'err');
    return;
  }
  const newLevel = lvl + 1;
  if(newLevel > 3){ toast('Vous êtes déjà au niveau maximum !','ok'); return; }
  currentUser.level = newLevel;
  const stuIdx = DB.students.findIndex(s=>s.email===currentUser.email||s.id===currentUser.id);
  if(stuIdx!==-1) DB.students[stuIdx].level = newLevel;
  const usrIdx = DB.users.findIndex(u=>u.email===currentUser.email||u.id===currentUser.id);
  if(usrIdx!==-1) DB.users[usrIdx].level = newLevel;
  if(fbReady && currentUser.email){
    await firebase.firestore().collection('users').doc(currentUser.email).update({level: newLevel});
  }
  saveData();
  toast(`🎉 Félicitations ! Vous passez en Licence ${newLevel} !`,'ok');
  sendLevelUpEmail(currentUser.name, currentUser.email, newLevel);
  showLevelUpModal(newLevel);
  renderLevelBadge();
  goPage('courses');
}

function showLevelUpModal(newLevel){
  const el = document.createElement('div');
  el.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:9999;display:flex;align-items:center;justify-content:center;padding:1rem;';
  el.innerHTML=`
    <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:20px;padding:2.5rem 2rem;text-align:center;max-width:380px;width:100%;">
      <div style="font-size:3rem;margin-bottom:1rem;">🎓</div>
      <div style="font-size:1.4rem;font-weight:800;margin-bottom:.5rem;background:linear-gradient(90deg,#60a5fa,#34d399);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Niveau validé !</div>
      <div style="color:var(--muted);font-size:.9rem;margin-bottom:1.5rem;">Vous avez obtenu la moyenne requise et pouvez maintenant accéder à la <strong style="color:var(--text);">Licence ${newLevel}</strong>.</div>
      <button onclick="this.parentElement.parentElement.remove()" style="padding:.7rem 2rem;border-radius:10px;border:none;background:linear-gradient(90deg,#3b82f6,#10b981);color:#fff;font-weight:700;cursor:pointer;font-size:.95rem;font-family:var(--font-body);">Continuer →</button>
    </div>
  `;
  document.body.appendChild(el);
}

function renderLevelBadge(){
  const lvl = getUserLevel();
  const prog = getLevelProgress();
  const badge = document.getElementById('level-progress-badge');
  if(!badge) return;
  badge.innerHTML=`
    <div style="display:flex;align-items:center;gap:.6rem;font-size:.8rem;">
      <span style="background:rgba(59,130,246,.15);color:#60a5fa;padding:.2rem .6rem;border-radius:6px;font-weight:700;">L${lvl}</span>
      <span style="color:var(--muted);">${prog.done}/${prog.total} examens · ${prog.avg}/100</span>
      ${prog.canPass?`<button onclick="requestLevelUp()" style="padding:.2rem .7rem;border-radius:6px;border:none;background:#10b981;color:#fff;cursor:pointer;font-size:.75rem;font-weight:600;font-family:var(--font-body);">Passer en L${lvl+1} →</button>`:''}
    </div>
  `;
}

function filterLevel(l,btn){
  const isAdmin = currentUser && currentUser.role==='admin';
  const userLvl = getUserLevel();

  document.querySelectorAll('#lvl-tabs .tab').forEach(t=>{
    const tlvl = parseInt(t.dataset.lvl||1);
    if(!isAdmin && tlvl > userLvl){
      t.classList.remove('on');
      t.style.opacity='.4';
      t.style.cursor='not-allowed';
    } else {
      t.style.opacity='1';
      t.style.cursor='pointer';
    }
  });

  // Bloquer accès aux niveaux SUPÉRIEURS seulement
  if(!isAdmin && l > userLvl){
    toast(`🔒 Niveau L${l} verrouillé. Validez d'abord la Licence ${l-1} avec 80/100.`,'err');
    // Afficher le message de verrouillage
    const prog = getLevelProgress();
    document.getElementById('course-list').innerHTML=`
      <div style="text-align:center;padding:3rem 1rem;background:var(--card-bg);border:1px solid var(--border);border-radius:16px;margin-top:.5rem;">
        <div style="font-size:2.5rem;margin-bottom:1rem;">🔒</div>
        <div style="font-weight:700;font-size:1.1rem;margin-bottom:.5rem;">Niveau L${l} verrouillé</div>
        <div style="color:var(--muted);font-size:.85rem;margin-bottom:1.2rem;">Validez la Licence ${l-1} avec 80/100 de moyenne.<br>Votre progression : <strong style="color:var(--text);">${prog.avg}/100</strong> (${prog.done}/${prog.total} examens)</div>
        ${prog.canPass?`<button onclick="requestLevelUp()" style="padding:.6rem 1.5rem;border-radius:10px;border:none;background:#10b981;color:#fff;cursor:pointer;font-weight:700;font-family:var(--font-body);">🎉 Valider ma Licence ${userLvl} →</button>`:`<div style="background:rgba(255,255,255,.05);border-radius:10px;padding:.8rem 1.5rem;font-size:.82rem;color:var(--muted);display:inline-block;">Complétez tous les examens L${userLvl} avec 80/100.</div>`}
      </div>
    `;
    renderLevelBadge();
    return;
  }

  // L'étudiant a accès à ce niveau — afficher les matières
  document.querySelectorAll('#lvl-tabs .tab').forEach(t=>t.classList.remove('on'));
  if(btn) btn.classList.add('on');

  const subjects = DB.subjects.filter(s=>s.level===l && s.active);
  document.getElementById('course-list').innerHTML = subjects.length===0
    ? `<div style="text-align:center;padding:2rem;color:var(--muted);">Aucune matière disponible pour ce niveau.</div>`
    : subjects.map(s=>{
        const files = (s.files||[]);
        const filesHtml = files.length===0
          ? `<div class="pdf-placeholder"><div class="pdf-placeholder-ic">📂</div><p>Aucun document pour l'instant.</p></div>`
          : files.map((f,i)=>{
              const fileName = f && typeof f==='object' ? (f.name||'Document') : String(f||'Document');
              const driveId = f && typeof f==='object' ? (f.driveId||null) : null;
              return `
              <div style="display:flex;align-items:center;justify-content:space-between;padding:.7rem .8rem;background:var(--card-bg);border:1px solid var(--border);border-radius:9px;margin-bottom:7px;flex-wrap:wrap;gap:.5rem;">
                <div style="display:flex;align-items:center;gap:9px;">
                  <div style="width:32px;height:32px;background:#FCEBEB;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;">📄</div>
                  <div>
                    <div style="font-size:13px;font-weight:500;">${fileName}</div>
                    <div style="font-size:11px;color:var(--muted);">PDF</div>
                  </div>
                </div>
                <div style="display:flex;gap:6px;">
                  ${driveId?`<button class="btn-pdf btn-view" onclick="previewPdf('${driveId}',${s.id},${i})">👁 Aperçu</button>`:''}
                  ${driveId?`<button class="btn-pdf btn-dl2" onclick="downloadPdf('${driveId}','${fileName.replace(/'/g,"\\'")}')">⬇ Télécharger</button>`:''}
                </div>
              </div>
              <div id="pdf-embed-${s.id}-${i}" style="display:none;margin-bottom:7px;"></div>`;
            }).join('');

        return `
        <div class="pdf-section">
          <div class="pdf-header" onclick="togglePdfSection(${s.id})">
            <div class="pdf-header-left">
              <div style="font-size:24px;">${s.icon||'📚'}</div>
              <div>
                <div class="pdf-name">${s.name}</div>
                <div class="pdf-meta">${files.length} document${files.length>1?'s':''} · L${s.level}</div>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:8px;">
              <span class="pill-lvl l${s.level}p">L${s.level}</span>
              <span style="font-size:14px;color:var(--muted);" id="pdf-arrow-${s.id}">▼</span>
            </div>
          </div>
          <div class="pdf-preview" id="pdf-section-${s.id}">
            <div class="pdf-embed-area">${filesHtml}</div>
          </div>
        </div>`;
      }).join('');

  renderLevelBadge();
}

function togglePdfSection(id){
  const sec=document.getElementById('pdf-section-'+id);
  const arrow=document.getElementById('pdf-arrow-'+id);
  sec.classList.toggle('open');
  arrow.textContent=sec.classList.contains('open')?'▲':'▼';
}


/* ═══════════════════════════════════════════
   LEADERBOARD
═══════════════════════════════════════════ */
function renderLB(students){
  const sorted=[...students].sort((a,b)=>b.avgScore-a.avgScore||(b.passed-a.passed));
  const medals=['🥇','🥈','🥉'];
  document.getElementById('lb-body').innerHTML=sorted.map((s,i)=>`
    <tr class="${i<3?'top-'+(i+1):''}">
      <td style="font-size:17px;">${i<3?medals[i]:'#'+(i+1)}</td>
      <td><div style="display:flex;align-items:center;gap:8px;"><div class="avatar" style="background:${s.color}22;color:${s.color};font-size:11px;font-weight:600;">${s.initials}</div><div><div style="font-weight:500;">${s.name}</div><div style="font-size:11px;color:var(--muted);">${s.email||''}</div></div></div></td>
      <td><span class="pill-lvl l${s.level}p">L${s.level}</span></td>
      <td>${s.passed}</td>
      <td><div class="score-bar-wrap"><div class="score-bar-bg"><div class="score-bar-fill" style="width:${s.avgScore}%"></div></div><span style="font-size:12px;font-weight:500;color:var(--b8);min-width:32px;">${s.avgScore}%</span></div></td>
      <td>${s.certs} 🎓</td>
    </tr>`).join('');
}
async function refreshLeaderboard(){
  if(fbReady){
    try{
      const fbStudents = await fbLoadAllStudents();
      if(fbStudents.length > 0){
        // Remplacer complètement DB.students par les données Firestore
        DB.students = fbStudents;
      }
    }catch(e){console.warn(e);}
  }
  renderLB(DB.students);
}
function filterLB(q){renderLB(DB.students.filter(s=>s.name.toLowerCase().includes(q.toLowerCase())&&(lbFilter===0||s.level===lbFilter)));}
function filterLBLevel(l,btn){lbFilter=l;document.querySelectorAll('#pg-leaderboard .tab').forEach(t=>t.classList.remove('on'));btn.classList.add('on');filterLB(document.getElementById('lb-search').value);}

/* ═══════════════════════════════════════════
   CERTIFICATES
═══════════════════════════════════════════ */
function renderCerts(){
  const userKey=currentUser?.email||String(currentUser?.id);
  const mine=DB.certificates.filter(c=>c.userId===userKey||c.userId===currentUser?.id||c.userId===String(currentUser?.id));
  const list=document.getElementById('cert-list');
  const none=document.getElementById('no-cert');
  if(!mine.length){list.innerHTML='';none.style.display='';return;}
  none.style.display='none';
  list.innerHTML=mine.map((c,i)=>`
    <div class="cert-outer">
      <div class="cert-card" id="cert-${i}">
        <div class="cert-watermark">ERSE ACADEMY</div>
        <div style="font-size:36px;margin-bottom:.5rem;">🎓</div>
        <div class="cert-top">ERSE ACADEMY · Certificat Officiel de Réussite</div>
        <div style="font-size:12px;color:var(--muted);margin-bottom:3px;">Ce certificat est décerné à</div>
        <div class="cert-name">${c.studentName||currentUser.name}</div>
        <div style="font-size:13px;color:var(--muted);margin-bottom:3px;">pour avoir réussi l'examen de :</div>
        <div class="cert-subj">${c.subject}</div>
        <div style="font-size:13px;color:var(--muted);">Score obtenu : <strong style="color:var(--gc);">${c.score}%</strong></div>
        <div class="cert-divider"></div>
        <div class="cert-footer">
          <div style="text-align:center;"><div class="cert-seal"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKcBBgYGBgcGBwgIBwoLCgsKDw4MDA4PFhAREBEQFiIVGRUVGRUiHiQeHB4kHjYqJiYqNj40MjQ+TERETF9aX3x8p//CABEIBQACQAMBIgACEQEDEQH/xAAzAAEAAgMBAQAAAAAAAAAAAAAAAwQCBQYBBwEBAQEBAQEBAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAAC5kAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4PXg9eD08PXnoeeg8PXnoeD0AAAAAAAAAAAAAAAB4PTw9eeg8PQHkhgz8MQAAAeAAAAHph76D3wAx9eh6AAAAAAAAAAAAAAAMffPQAAADGxBOe5Y+EQADAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGbAZsBmwGIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyKyyPpgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHnuHNmOgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHJFwso7QKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQzQeWzj0wKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAV7Ffw6sD2ZDQAAAAAAAAAAAAAAAAAAAAAAAADz3H3m9HQAAAAAArWa3z9WPfPfbkNgAAAAABhh7l56BsAAAAAAAAAAAAAAAAilw4XNHJuB0AAAAAKtqr8zdn3HL3YDqAAAAACEWM3kvo9kAAAAAAAAAAAAAAAAACIJsY/Bqce/IUAAAAq2qnyt2M45PdkO8AAAAARZweHUkp6ch1AAAAAAAAAAAAAAAAAAK1mPya9zrWUD1wAAADyrZrfI6TyRS+7AemAAAACHjcJY7Hj0H0cBQAAAAAAAAAAAAAAAAAARWk9h+N0tPPfscw0AAAxrWa3xuk0sM3uwHrgAAA8jGv7n8XpLkfY5hsAAAAAAAAAAAABj77HxSIpNPR0AAAAKtqLw6wsVJ+NkH1MABAxw8ryxfH6yT15fZjNj77c+jYABXzh+Vtaim6wPoZAAAAAEeEjDMDYAAAAAADCOfHyX32tJmyj2ZCgAAiqlh/P8AW17D79bnLhDj5NSYePFsOY9V49HntWzWecLpLapJ78z4+Q9Z48m+ZuT0+/yCgAAB5HuMfnj0me9YHogAAAAAAAAHley8trzwY+HdpHJ9TmHQAEeVpIvjdB74d+JZPbiHOV7845HpyGiOTSJrup1e3zYcLLyaqLMPz94Dy6ys1Z/qc8x9PAUAAYw+ayReT+HWMp9LAdQAAAAAAAAAACCdwtST2L4/S17Vn+ljMevPkHmPx+h7L59YT+vs8g9MAAAcb1HN2dZkSgBGENl5bUSxfG6zyVJvo4lH0sDDLOKPH5fT33KbJ6fX5hoAAAAAAAAAAAAAilclRPD8Prnjih6sbeZn3OQbAAACqaW3y3dazYGdAAAIpXJUTwfD7TSVffTnON75NeTeyfRwH0cBQAAAAAAAAAAAAAACGSv8/XhN8zplmff4h0AAY0tes8128t1xWHfSHzbdWdpZek4zqM22JQAAEMzjajPD4HXKeKf6nMPo5AAAAAAAAAA89R80iH3lZWGfaBsAAMcooz872zsY5fa5B6oAAAAABzXS8x09kXL9ajUbfQ410AlAAAVbUXg1DZrZ+Ddgfd5BQAAAAQAFAAAMM2EGFp49V80fm1PlU91LSvn6pLBnDwvkkdnzaywz0f3OO1fO259Ex+e+H0v2ncxVex89runzxqfRpfmu7jr3nudcv1HJ9ZYazkztoeDan0eT5tupevYZ5qCfhbOzfO2p9D9+d7GOw8mh/Od7OUE/2OYeiDDDNFjws/ldw1Nj5J0mHsjvPPTtAoAAAAAIwisPNai1F87cQ8W87Ecn3OSraezOkx3qzQt8IpSVrNmNXDulnzqHbanpnu9hqNvy1yXWcl1dcBXTdM7mxvJ+euDofQub1LXR6Df5rn+gRyzqVctZ6AeVrVf5nTGWF8/cmOPtjzOTohzne3GGZ7chsAAAAAAAAAA89w5q57+d7WMj9JxafcanU5X06RLFKd0OenP9B89s3lbRt5ynw7pZ5Dnrjuw43s7nhtb9G0GnNXvKNnQ7rgy/S3PdDzrl+o4apmobzt9xyHRy9PHJ55t1ffMvz/WST1+g5B2gAAAAAAAAAAAACKWDyajzwl+TuYfoeQwM1cWFcWGOQqWxS57ro7PnG90vm8/SUUvPfF9XyXTazWucDcrv4IrWLo+S7Xity53/AAPfSscmaCePShFXzLH832tscv0XENgAAAAAAAAgYYZoseNnVvOFs413DU0XjzVNDJpOwfZ556LdUU4V0rpOadKJ9/rb/O5sC5sBx+n7rVbzN0Gj3GbwPdcj1epzOl+j6s4x0ONaD3otvFbdR+4ufEdppK5V0Tc533oR0mUWXPUWGeHwuuecLcs+1XoltVy9GbCLL0TMdoGgAADHJEfkrhYUzCFMIUxYUvhGmJD7KqJKqFMiLyZUXkwh9xqlxr5yz5JkQphD7KiJKqJKIUlAttNFW+arZxkmEKYQphD7KiJLXM2sqVvmivF5JllCmLB7MSPLJ2gdQAAAACKXmkzobODUp+vK8nxtG5tcmzesa69GZAs7TaizdaS75UNvXe2bGKtHC3UtHS5cbbl6dqpI2LT62un5+lsa1uwp4WbJWml9qZVrM+i0eMdW42xL1TmoDrNfz1wqSz0bNooWjPHyoYbrS7xdqM0AAAAAAABzXS6pNbf0tjU2OGUssUfutrC5DcsjqMT2WEbOKrtJdRttfiW6O92Bx+fXxmjjvaUX8c098o4Gz9198oTXdQbfW3N0vJuyRxtjqqxqdbZislsS4r57jIUq26oJZw12/XQedj7HGuy8OevKR0IlAAAAAAAAUroxyAACvzfWE4+90NKqMF+c53Lq8incJQAANPp+wWcdn13hx7sPa0G8zZAoACCcc5R7FZxvvYjmd1cQCgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOd6LlDZ7XWag6zHlITsXMSm7k5XM6vzlqp23P7nniXoeTlOox5aA7LzmpTofNFQOtx0WpOj2HJ3DdQ6KM3ux5ykdjjykh1WGPFnU7DkOrNP7gN75zdU6ypqqhu9lxGyOjz5SM61x051mqlpGO80eB0PnPak7jzk7B0lDV0DqI+fuHSec5UOuaCsdTjy9Q7YAADmemGnw3Y5eTpBpq3RaQ1drb3jQVOqFOhuxoouiGgx6Ec1Nvxy13eDn63UjmsenHLR9aNDX6YaCr1Ij5frBzu+kHPOhHK7THcHOQ9SOWvbsabXdUOal6AaiPdjn5d2NHQ6sc9Putaalsduc750Y52r1lA0F3oRodd14xyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADhGlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppRumlG6aUbppQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0gjSCNII0g9AAAAAAAAAAABsNtzI6ZzI6ZzI6ZzI6ZzI6ZzI6ZzI6ZzI6ZzI6ZzI6ZzI6bTUgAAAAAAAAAAAB/8QAAv/aAAwDAQACAAMAAAAhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMMMEIIEIMAAAAAAAAAAAAAAAAMEIEAEIAAAAMcIoQkgc4gAAAAAAAAAAAAAAAI4Eo8wAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAECAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASAAAAAAAAAAAAAAAAAAAAAAAAAAAnAAAAAAARhAAAAAAAGCAAAAAAAAAAAAAAAAAALAAAAAASrAAAAAACPAAAAAAAAAAAAAAAAAACfCAAAAAHCAAAAAAejAAAAAAAAAAAAAAAAAAAQpAAAAA+KAAAAAAwCAAAAAAAAAAAAAAAAAAACRAAAAA/LAAAAEZCAAAAAAAAAAAAAAnNAAAAAWtAACDUlPAAAdpAAAAAAFKAAAAAAAAjOCAAAAXlX+995lPKMdgAAAAEA6AAAAAAAAAAxuJAACG43QBADqi28pCAAAPhBAAAAAAAAAAAAAkuCu2jAAAACgACB2OCHKGCAAAAAAAAAAAAAAD79qDAAAAAFAAAAT0q6qCAAAAAAAAAAAAAAAAJyDAAAhwKglAAAAS/TAAAAAAAAAAAlKJAAAAeBAAAAAAAoTEAAAAGqCAAAAACCAAAARxoJAIoDDFJFzjIKKjMAVDx9BCHJSsQiAAAAAACxz8AABhAABjLqGKPhDCRGcpMRhAAAAAAAAAAAR/gXucASjIA7AbELSDTC7iAAAAAAAAAAAAAAA/AACCIQBHIX0bWIQBgAeBAAAAAAAAACFNP8AndzHwgrzDI6dYQnrysIDNjXjxggAAAEIgwcNMYQc0UYjkcYwQedOsccYxwjs4IwwAAAAAFzylSgxDUoR37yzeLYOfzzmvy43AAAAAAAAAB34qIdHPPsMCl29T5Mgi1IOyMtkwAAAAAAAAAIAAE6msoAAAIQuEwAAEMgswAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFBPODIGGDDDEJACOEJJAMIJMLGOPPCAPDAAAAEAFMIEMEIEEIIAAMEMKAEIIEIIFKAMEAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAP/EAAL/2gAMAwEAAgADAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACDDACCBCAAAAAAAAAAAAAAAAABAAAAACAAAAMIBFOFINOEAAAAAAAAAAAAAAANLELBDKAADDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPOtPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPKPfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPL9/PPPPPPPPPPPPPPPPPPPPPPPPPGvPPPPPPKdPPPPPPPO1/PPPPPPPPPPPPPPPPOtvPPPPPK1fPPPPPPEfPPPPPPPPPPPPPPPPPLlPvPPPPAvvPPPPPI3fPPPPPPPPPPPPPPPPPPPN/PPPPAl/PPPPOHPvPPPPPPPPPPPPPPPPPPPCt/PPPIl/PPPOdX/ADzzzzzzzzzzzzw/7zzzzynDzz7KhHbzzzDfzzzzzzh/zzzzzzzwnT7zzy75efMUcshJiI7/AM8886tv8888888888Pw2888pjVM8+/veOLO+888uPf8888888888889P47Z2+8888y88+9HT+40X9888888888888889KdT888886r8888tg8Fu+88888888888888885Ke888ed8T08888+hu88888888888e928889sW8888888/b78888Zt+88888++8888+QQ38jWpwu/uwZ09t4y84wjj++23qbNc8888888/sP2+cs8+MEX29fi299uuCRens88888888888v0/rqT0/TQ8XHaG1/38oKc88888888888888uB88ww8+Mu8EzRfWsDW/z88888888888/+9+xM83MN7++EW91Ij1jPNSE/wBPsdfPPPLT/wD0QgW8z5xyEFTy4yzLTHzzy4cUmcx1zzzzzzy9MXNHXbaxzs5DfpxSqHXzmO/nWbzzzzzzzzy7k67XtNraDRSVO/H3OJd6yGp/qLzzzzzzzzy7zzz/APXV+888u60d888uNdO8888888888888888888888888888888888888888888888skwcowwIQ4AI40o44EYcoMwk0E0YEAQ8Q0888ccc8M8MMs8MI0c8csIsc8ccoM8IMc8Ecc8888888888888888888888888888888888888MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwAAAAAAAAAAAAwwwwwwwwwwwgAAAAAAAAAAAA/8QAQxEAAQIEAgUIBwUIAQUAAAAAAQIDAAQFEQYSEyExQVEWICIyVGFxkQcQFDBCUpIjM0BigRVDRFBTY3KxNCSCg5Cg/9oACAECAQE/AP8A3cz7qmmQoH40jzMD+R19ZRJII/rI/wBwjqp8P5HixZRT2rH9+iGvukf4j+R44Xlp0uOMwmJU5pZk8UJ/FpmrTamF6iRdHePcY/XaSlB/einm8jKn+0n3E1MolmVOLPgOJiU0pZSpzrK124fgq4y6ZYTDI+2YOdPeN4inTzU9KNvtnUoaxwPP9Ii7MSQ/OYo6s1LkjxZTzyqwJOoDfDD5rNUKkn/pZVWr86/wZAIIMSr6qJX3JRzVLzRztnck8/0in/hDxjDys1Gkj/aHPxRV1jR02UN33yEkj4QYpVPRISTTCQLpGs8T+ExdTVzlNU40PtWTmSYwpWU1GQQhavtmuioc70iLvMyY/IYwqrNQZI/k51aqzNLklvLPSOpCeJjB8g/NzD1WmgSpSiEAwPwikhSSkjURYxMafDeI1LTfQrVfuKTEvMNTDLbzarpWkEc30hqvUZZP9uMGqvh+U/XmvOoZbU4tQCUi5JifnJjEtcaZbvoUrsnuTxiUlm5WXbZbFkoSB7+dM5Lq07H2iP3jZ4cUxI1KVnUFTK9Y6yTqKedjWlGcpwfQLuM6/ERgeuWvT5hfe0fWVJG0iHajIM30k00kjioRjWbYm6qlTLgcSGwARGDqvIMUhpl6aQhYUdSjDc5Ku/dvIV4KBgEH143r5VensHUPvSIwPRjKyxnHU9N0dHw581Py8rYLX0z1UDWoxLOPOIKnEZL7Bv8Ac1iiOqd9tp6tHMp2gbFxScVIdc9knk6GZGo31AwCCAQbg8xxCXEKQoalAgxWZN+i1lejuMq87Z4iJLFVNXS25p94JXlspO+8VL0grN0yLOUfOuJuv1acKtJNLtwBsIs+9rIWswJGeOyXd8jBkJ0C6pZwDjlMOs1CSKSvSNlQunaLiJLFNZlCnLMKWPlVrEUzHzDxCJxnRnesbIxDiiVlabmlXkrcd1IsYw/TXatVEBdynNmdPdDbaG0JQkWCQAOa44htJUtQAG0mJvErk0/7JSmi6smxc+FMUykezK08y4XZlW1Z3eHu8QYbl6o0VpGSYSOisRT8Q1OhTRk6gkrbTqud3hEhUZWfZS6w6FA+takoSVKIAG0mMbVanTz7bbHSW1qLkNodcIS2lSu4RSsE1KaCXH7MoPHbEjgujSoSVtl1XFUNU+RZADcs2kDgmNG38ifKEstrISUJN+6J+nyE4oB6XQsJFhcRPYGpMwFFoKaV3RVcHVSRClJTpW+KYKVpICkkHZYxgSfpjTS5cqCZlatp3wDccyr4kp9MQoLWFubkJhlyt4qmACVMyiTr3RTKTKU1kNsIA4nefe1qhytVlyhxICx1VQ6ir4bntRKRutsUIoOLpOoBLTxDT3fsMOPNttqcWsBAFyYxNi12dcXLyxIYSbE7CqKNQp6rO5UJs2D0lmKPhyn0xAKGwpzetW3mtdEKV3avWdkVvCcjUUKW2kNP7lCKjS5+lTJS6kpKT0VDYfCMLYtDuSTnV9LYhyBsETc7LSbRcfcCUiK5jh54LYkAUpOrPvig4Umak4JufUtLd72O1cMS7Mu0lppASlIsAPf1OlytSl1NPJ8FbxFboM5SJo6iW9qXBD1fqb0imTW7mQPOMNYceqz2Zd0sJN1K4xJycvJsoZYQEoSNnNAJ2Q4koaSnm1OlylSlyy+gHgd4MVujTNIm1BQOS90LEU/HT0vTtE43neSLIUYnajUqvMjSFa1qPRQIw3g1tjJNTyczh1pQfhgAAAAWH4HHNWaZkvYwAXHD5CKHR3qpOpZbFkg9NXARISTElLNsMpyoSPPmANW1qMBbI2IJj2gDqoAhx1JyhY1EQtsp17ubWKVL1OUWw6m5I6J4GKhIPSE05LvJsUkiMDyFMMmmZQM0xsWTu95MvTjJzNshxPAGxhOJJBLmSZzsK4LTYRLz0nMC7L7ax3HmTUwiWl3HlnUhJMVOefqdRdd1lTi7JEYXoyKZT0XT9q4Myz7h34P8YQsp8IUlJGZHNxtRBOSftbY+1ZHmmMJVZVOqTaFqs07qVAIIBB5xIG0gQCDs5s1JSs0gofZQsd4iewU0buSD7jC+F9UOvYwoqukVuo49YRKekN9JtNSYPek2iTxrRpgWU4WjwVGNa8wuQal5V5Kw6bqyndGCqV7ZUw6sXQz0v1hCcygmPZB88eyDcuCLEiGmw4q17R7GPnhcsQNRv6ntiPCG2FLF72ECVHzwuWI6pv6mkZ1WvHsg+eHpJBbWFG6SkgxiOmrplVdQnq5s6PAxhipifpbKlHpoGVcXAh6oyLAJcmG02/NE1jKiMXAf0hHyiFY6L68kjIOOqOyGDiyfsVlEq2f1VEtRgmypmZdfV3mwhCEoSEpFhz1JSoEKAIipYTpM9clkIXxTqip4GqErdbBDyPJUKQtLhQraDaMGU4SlHbWRZbxzqgEg3EaVz5o0rnzeoKI2GA64PiMNm6Ek7Yc66vGHf3fhAGVvVCn3b7YamEkdMw6UlZIhKik3Ead35oLzhBBMY/p+llGptI1tmyvAxS69UaW08iXUBpOIvD1drs6bGbdJPwpiSwpXagoKcSptJ+JZin4Dp7GVUypTquGwRKyEpKJCWGEIHcPeVSYEtT5l4/C2SIYQqbnmkfE47/sxKshmXabGxKQBCLZ03i7PBMK0Nj1fUwgLUQYEu1fVDzmQWAgmHtiPCGpkBIBj7FY3QqWQoatULSUmxhgJKzm4QG2rbBDyGwg2AvFclBN0uba4tkiKe00ueYaeF0FwJIiQo1NkkDQSyEn5tp9/jOY0NCmLfGQmMKsaauSadoCwr15VcDGVXA+oEjYYQ6pKgbwtOdEHVDtjorwuXTlumLKHGJcr+KJm2cerXGuFpzIWniCInUezVN1I+B4/7iQd0slLL4tp90pSUi5UBD1UpzH3k20n/uETGL6Ez/Ehf+MP+kKQR91LrXEx6Q51V9DLNo8TeKliWp1NvRPujITsEYPfl5esNuvuJQgA6zH7fo3bmvOEYgowUD7cz9Ucp6F25n6o5T0LtzPnC8QUUrJE8z9Uft+jdvZ+qP2/Ru3s/VDOJqKEgGeZ84cr9FK7ieZ84mK/RihFp9n6oaxRRwADOs/VHKWg9uZ84ViiiAap1nzhWIaOo3M+z5wziGiJUSqeZ+qBiWgdtZ+qDiSgEECdZ+qDX6N25n6ory2l1aaW0oKSpwkERJYrrMmlCETF0J2JIuIlvSFOJI08uhY7olcf0x22lacbiWxLRZi2ScQCdx1Q3MMOAFDqVeB5rredBTcjwNodw/JP/ereP/kMHB1EO1lX1GORdC/oHzjkXQv6B+qORVD7OfOORdC7OfOBhCgj+EjklQuyCOSVC7II5JULsgjklQuyCBg+iH+CjkdROxRyRoXZBHJKg9kEHCVB7II5JULsgjklQuyCBhChnZJiORlG7EIODqKNskI5JULsgjklQuyCOSVC7II5JULsgjkhQjslBHIyjdig4Moo/goVg2hE/wDGI/WORVB3MK+qG8I01o3bdmEnucMS9O0BSRMvKA3KVfnoCSdZtCQn4G/OLvD5YVc9ZsHwgtA9QwUKG0GMp4GA0oi+yEADUhNzxMHPvcSIF9zwhQJ6wB7xBZJuUkERo1/KYDKzutCUIB+Y8IObeoIHCAWx+9VAN+q75wpKSOkMpjQq3WMaBzhGjQOsoeEdMCwASIuje6qAUfC4b98O5rawD3j3Td82oXhX53P0EXa4kwnJfouEeME/P9QgZ/hdBi7p2rTByX1kqMEXF1kJHCM7I2IJjSt724TkJ6C7dxhWX4gQeIi5t99Byb3CYBV8IyjeYKmknYVGNN+QQHUHrIhN7HIrN+UwdHvSpMfZfMowm/wI/UwvIDdasxjTAbECNKDtQIOjKTlJHd7oEjZzErKY0jR2twFMfIYLtuqLQSSbnmJeWBbaI0rZ2tCNMB1UAQpalbTzASDcRp3N+uNMrgIU4s7/AP4Hv//EADIRAAEDAQUGBgEEAwEAAAAAAAEAAgMRBBIhMVITFCBBUWEQIjAyQnFAM1BigSOCkKD/2gAIAQMBAT8A/wC3LRU/skYq7+v2SAVcfpHP9jswq8/Sdmfy6YV9Cye530n+5336AFSjn+FGReocinNLXEcdjFS5Se9336BGzZ/I/iEbSIO5t47Fm5TfqP8Avjgjze7IJ7rzifxLO+6+hyKnjuPPQ8VjycVP+q7ijjL3ABWhwaBG38YUng7hEUNOGxexytH6ruEAkpgEEJPNOcXEk+u26cCnMc3is0l19OqtUWN8cAY45NKsrXNZiFaY3GQkNKLXDMcFmh+ZVqkvOujIcbWko0Hoxyil1+LU+AgXm4jhCicJYk6B4eQAo7HzcU2CNvxCqBhVX26gr7dQTSx45J9njdyT7I4e01UUDnPxCmfs46BE1PCBVNgAbekNAnyVwaKD04pjGeyfCyVt5icxzTQjgssb2gkokDEqS1NbgMU60yO7IvccyVUomgUbnNAoU20vGeKjtTHYHBAhWpjya8uGOF7+WCIjgHVyfI55qT6sUrozUL/HO1S2dzMRiEASaKCANF5ylmbH9qSZ7zieF5xA4Ip3MPUJj2SDDnmrRZ7uLfBrS40AUVlAxepZ2sF1iJJNT67JHMNQo5WSAdeaEDA4uop5RHlmnOLjUniaQ55PCx7mGoKilZI2vPmn2Wr6jJMjZEFPaSatbl+FZoyXXlLIGNqc09xc4k8BLuQRDyrh6pjXDEJrq4HPhjeWOBCY8PbUK0ufeocvUAaea2TuWKLXDMcDRUgKNuzZTop5C956egz5faIqgXDA8Nmluup1Vpjvsr6ocW5FNtJye0EICzS5YI2MH2uTrNIOVVZojfJcFan3WAdUTQEra9lteyBqE510La9kJQfBny+054ahKhID4OdQLa9k2XEKF9+JTx3HkeAY45AptmldyW60FXPAR3dn8k6XS0D0WTyM5qO1tOYQpmFaX3pD28LjeiuN6eN0dE8UdQJuQTPl9o+/FBjaJ0Z5JlbuKIBVxvRXGqyPo+ikhZIalbKNvxCdaImZBPtb3ZYJz3OzPqMF54CPljKJqSUciqPQD6jweSBgr7uqjbezPhHm/wC0+LGoVXtQlIQNQpCQMFfemOcSonXXtPdPNGEhPke44n17MKyhTmkTvGoVR4loIyTDdd4M+f2mymtCsCpAMKKPLww8AmG9F/SeKOI7+mGPOTShZ5TyTbI85lCxtGZJUULGGoCtILoiAOa2UmgowykHyFbtPpK3afSU2GUD2FbKTQVspNBTrPLXBhQilp7So4ZQT5SnWWQmoaVu0+kptmmObShDIPgU+CUjBpW7T6Vu0+krYy6SoQRGE6zxOrUYp1jHIp1keMjVGCUZtKIIzHCChK4ZAIWiQc1vMvVbzL1W8y6lvMupbxLqW8S6lvEupbeXUtvLqW8yalvMmpbxLqW8S6lvEupbeXUt4l1I2iQZuW9P1reZD81t5dS28upbeXUt4l1LeJdS3qTWt6frW8y6lvMvVGd5zARdXkOM15Kuoryd0Kcig7qqjwvBE9SsOTCvtiF3lVB3VXh1Rc0Ilx5UCH1VUdpCPcKpGWKvhF7VeJyCw51JQB0LHQmjHP0nUpiUOwXn7I3ugQockQ3QV5dJWPYIHoqP1K6/UvMBigv9EK8m0RPU1KAP0rncosPIo98FQ9QV5+yI1OQvHLBXDqKufyKANcvWLQVR4+So/qFcrmeEsCunUrh5uKDQOG4FcHUoNA/8D3//xABJEAABAwICBQgHBQYFAwQDAAABAAIDBBEFEhMUFSGSECIxMlFSVJEgMEBBU2FxI0JQgaEGFjM1YHIkNENisSVwwVVjgrCA0fD/2gAIAQEAAT8C/wDwYushWjKLSPZB+JDpQ6yPR7Tb8Ct6sEdqu297pzhb+jcyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLMsyzLN/9cTqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAVqVZ4aXgK1Ks8NLwFalWeGl4CtSrPDS8BWpVnhpeArUqzw0vAf8Atpff/RDukf0Q7rD+iHdYf0Q7rD+iH9b+iHdZD+h3dZN6Pxa+/wBhd0pnR7F0n8Ecmu3ewO6Uzo9hcU0fgvVd7AekqPo9gJsm7zf8GeNyYfX+9R9HsDjmNkPwc81yBv608kfR697lGPwiRu5Md608kfR65zrIc4ofhLhYpjt3rHdHJH60pxuUwbvwp43JpsfWO6OSL1r3e5NFz+GEWKjd6t/RyRese63I0WH4ZI3kad3qpOjkj9WTZE3TB7ebjoQdf1x3FMdY+qf0ckfT6txvyNFvX39hLfeg/t9bIORjvTzBZwnuBHI02K0gWYK/pvdyRj3+vLuxAexObdAlqDgfVkIoGxQ38peEZFmPqc5QkQcOVzrDkG8oD1pdZb3JrQPZC263tKa/1cg5GOsi9Fx9KxVirHk1qHT6G/P9EPKzhONzyMHrLpz01t0B7MRdFtk11kHepPpZShGsgWUehI5rGPcfcFhTDUVsk7vd/wCVkCMaLSPRaLn1hfZXJTWdvtJF05tkDZNf6hz/AEAxBvqMcnyU2j97ysGg0dID737/AECwIsPKDZNdf1JdZF5KtdNZb2xzORr7IG/oE2TnX5Qy6Dbeqr3mrxERjoByqNgaxrfcB6RYCi0jla/03ScgbdNbb25zOQGya/kJsnOvytZ6usn0FPI/5LBItJVOlP3R+p9RZOZysf6BdZFxPI1l0N34A5nK16cb8gF01tvWY/PujhH1KwOLJSZve8+qczlY5Eov5Ws7fwN7PRaLesnrIIWkuePoqqodUzmR3vVGGNpocvdHq3N5b8gTW2/BX25Wtt6hzmt6XAKTEqOPplH5KTH4R1I3FSY7Vu6oa1Pq62bpkefohS1T/wDSf5IscHZSN6oMVkp7RTdT/hRyMkaHNNx6t7eUC6a234KTblY31NRhE08z3mp3H3JmAQDrSOKZg1C37hP5puH0bOiFqbFGOhg5AwNxvoVbhsNSOx/amSVmGS2I5v6FUlZDUszMP1Hq3ttyMPtF/XPPI0XPsDv54OSaCOZhbI24VTh9TQyaaAnKqDFI6gBr+bJ/z6pw3crD7PZFiu8LSLMPUuNhytFh7BJ/PG+hXYQH/aQc1/YsPxCbSavUDn+4+qeORpsfX39WWAosK3hZyhIs4V/Qed/Iwb+R8scYu9waFr1H8dq16j+O1a9R/HatdpPjtTHBwBBuOU1dKCQZm3WvUfx2rX6T4zUyop39WVp/P0Jv52zlNkaumHTM3zRmw8yB5kjzD3pk0T+q8H0TVUzHWdK0Fa9R/Hateo/jtWvUnx2oVVNIcrZWk9iIseRhv6m4WcLSK7ysp95QHrcqMaLSOXOVpFnHK0WHJj3+Vb/f6OGn/Awf28tb/mp/7zygkdBWHYq+NwZKbsP6Ibxcck387b/cOTEMRZSt7XnoCnrqmc85/wCQ5Wvc03a4hUWMyRnLMcze33pj2vaHNO48uK/56X0MK/z0KkHIw7/QuFnC0izlZirEoRoNHsZjCLD6LRc8tXRsqmBjielfu/Td962BT996/d+D4jl+78PxXKCIQxMj7o5X4RRyPc4tNz81sOh7D5qXAqUt5l2lVED4JXRu6RyYTNpKOMk9G7kqP503+4ImwJVXMZqiR5PvQBJAHSoMBkcLySZfkj+zot/H/RVmHz0vWF29vJgNTcOhPu3jlq8GkqKh8gkAuv3em+MPJfu9N8YeS/d6b4w8lSYNJT1DJDIDZHo5c4WkKzHlsUIysgHtGUIs5Yx67GXA1pt2cmCstRN+Z5Kn+ct/uCl/hSf2lHpKpZRFPG8i4BUNTDM0FjweSrg08EkfaFsCo+I1UGFT01QJC8Wt6l43+iGFBgVvaz0crejlxmWWKmaWOLTmWv1nx3LX6z47ltCs+O5QV1WZowZndYehLjuilezRdBsj+0G7dCpMdqHNs1ob805xc4km5KpqaSokDWj6lQRiKJkY6AOSrP8A1f8A+Y5MTpHU87t3Ncd3I1zmm7SQosUrY+iW/wBVDj7/APVjv9FTYjS1HVfY9h9CuxWqgqnxstYfJbcrf9vktuVv+3yW3K3/AG+SwiunqnSCS263JJyAXQjVre3P6OQdPoY3DJNTtbG0k5ls+t+A5bPrfgOWz6z4DlBQ1YmjJhd1h6FZ/mp/7zywGESDSglvyVHq2hBgAy8tb/Nf/kOSaGOZuV7bhT4B74pPyKlwysi6YifoiCOkcl7LB8QMn2Mh3joPLioOvS7lY9isexZT2L9n+vP+XI7o5G9P4BJyM6fWHDqNxLnQi5Rwyi+C1YnhYg+0i6nvHZyYJV5JtCTud0fXlr/5of7gqmpZTxaR4Nlt2i7HKkroarNo77uSSmgk68YKq8FhcwmHmu7PciLGyoHFtZDbvcuUdiyM7oWRndCyM7oWUDoHIUeQdHt8nTyR+hJNHELvcAFtCj+O1bQo/jtW0KP47VtCj+O1RTxS30bw70Z4myxvYfeFIwxvcw+4pjyx7XD3FU0wlgY8e8clf/M3f3BYjFpqKQDsvyUVW6lmzjo94UFfSTDdKPotYh+I3zVZitPCxwY7M/5Im5usOYX1kP1vy5m9qzt7Qs7e0LO3tCzN7Ryu6eRnR7ZmC0gWkRN+SP0Me/yrP7/R/Z7+DN/d6WNQaOqz+5/JgNReJ0R+70clW4uqpTf7ypudTRf2hYnhr4XmSMXYf09EAuNgN6wrD9XbpH9c8uKPeK2WzitJJ33ea0knfd5rSyd93mtJJ33eaj6jfpyP6eQOshItIFm9jzBaQLSLSLM5XPpMcAtIFpAtIFXU7KuMMLrb7rYcXxythxfHK2HF8crYUXxyqCmZRse0PvcrSBaQLSBaQLShV1LFVsDSbWPSthxfHKo8NZSzaQTE/JZxZPwusL3HKOlUpMdPGx3SBvRc09KnwyilN7ZT8k7Au7P+i2E7448lHgbL/aTeSp6Okp+o3f2rOFpAtIFVYVHUTOk0pF1sKL45WwovjlbDi+OVsOL45TXNaAFpAnG59K5WcrSLSBZh6s3VndqyHtWjWjK0ZWjWjK0ZWjK0ZWjK0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0S0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0ZWjcsr1z0L+w3CDm9vrZKqCPryNCOMULf8AUQxyiJ6SEzFKJ/RKE17XC7SD6pz2tFyQFJi9FH9+/wBE7H4PdG5D9oR74VHjtKesHNUNbTTfw5B6m6lqoIevIAn47SNvlzFO/aBn3YSm4/F74XKLGaJ/3rfVMkY8XY4H2WWeKFt3uACnx5g3RMv9VrWLVHUDrfILUMVf0l2//cjhWJM6HeTlkxiDv/8AKhxydhtPHf8A5VNiFPUjmO39nqKzFoIOaOc75I1WJ1p+zBA+SjwKd++WW36oYFSjrTFbJw07hLv+qfgMR/hzo0OJUhvGSf7VSY24OyVA/NMka9t2m/pPkYwXc4AKqxvfkp23Pam0eI1pzSEgfNMwSlYLzS/+Fq+Cs3Es81mwR+7mLUsHm6sgH5qXA5W86CW6ixKto3ZJ2kj5qmxCnqBzX7+z3+jdVOJU0A3vuewKTEq+rOWFpA+SiwOeTnTyW/UrZmGRdd/mV/0SPuLLgb+4nYRRSj7Gbf8AW6dQ4hRHNG4kfJYViD6nM17ec32SfC6qpq5C91mX3IR4VQ9Ygu8ypMeaN0UXmjjVa7qtHktpYozeQbfNqZjtS3rxtK2hhtVumiylTYSf4tHJmH1UGMVEByVDL281Di9FJ9/L9UyaJ3Ve0/msw7U+spmdMrR+anxulYOZzyn1uIVxyRCw+Sgwunp26WreL9imxqKPmU8S0mL1XRmt5LZOIv3ud5lbCq7XDxdbMxOLqk/kU3EcRpXWlBP9yM2H4gLOGik7UYMSoDdly35bwocfI/ixeSZjlE73kLbFB8VPx2kHRmKmx2V+6GOybRYjWm8pIb80GYdhvWOaT9VLi9ZO7LAy303lDDMRqN8jrfUpv7Pm3Om/RH9n4rbpnXT/ANn5fuTBaLFaPeM1vlvCjxSCcaOsiH1UmEX+1pJbhazitJudmt896Z+0Eo60IX7w/wDsfqn49UO3MjaETi9X3reShwRjBnqZE/FaSmaWU0d/n7lpsVrOrmt5BNwKpd15QP1Tf2fZ96cp37Pt+7Mn4LWRb433/RMr8RpDaUEj/csPq6WfMY25XnrD2TEJ659S6nhvb5KnwMnnVD/yC0WFUvTkv895W1cOZuH6Bbbo772u8ltDC5esB+YTsLw+pF4X2+idT4hh7szDdvyUeI0VUA2qjAPanYNSzc6Cb/ynYHWN6r2lbGxDtHmmYDMTz5QP1WzMOphmldf6qbGKeJuSmZ/+lFRVte/STEhvz/8ACbT4bQjnEZvmpsdhbuijJ/ROxysPVY0LamJdb3fRNxyrB5zGlMxmkm5s0Vv1U+GU1QwyUjxfs9yixGsozo5m3HYVrOEVXXaGlbJw6TqS/qtg03xnLZmGRdd/mUa3CqYfZgE/JSYrV1JyQMt9OlUuDPcdJVO/JOrcOoxkjAv/ALVLjdS82ijA/VabGJd40nktDjHW+0WnxiLec/5hQ47KDaaO/wBEY8NxDqnK/wDVOpcRoHZoyS35KLHT0Tw3+i17CJevGPJaXA+xnktpYXF1GeQU2POO6GL8yhBidd1yQ357gosOoaNuadwJ+amxyBgtDHf/AIRxPEpjzB5BWxl+77VZMZj3faIYlicHX/UKPGKaYZKiO36hUdHSMkM0DtxHsldicVKctrvWsYnXHmXA+SiwGR2+WWyZgFJbe5xRwShtaxUmAU/3ZHBSYRWwOzROv9OlQ4vUwOyVLbj9VqeHVwzQuyu+SfhNfAbxOv8AQ2WnxiHpz+S2jivz4Vmxmb4n/CZgtVKbyyW/VMosPohneRftKqcXmlfo6Yfn71Bg1RMc9Q+3/Kiwmij/ANPN9U2CJg5rAFYJ9PC/rRtP5KfBqOToGU/JS0FbQu0kTrge8KHE6WpaI6pm/tUmC0kovDJb9U7AqpvUe0rZGI//AMU3Aqk9eRoUeB0se+R5P6J9dh9G20dr9jU+pr8QfljBDVTYFEN8zsx7FHSwQ/w4wPQnoaWbrxi6qsFezn0zvyUGLVNM7RztJH6rSYTWdbLfyKOC0L+o8hfu/B8Z3khgtCzrOJ/NXwqk7l/MqoxwnmwR/mVDh1bWuzykgdpVPg9HF9zMe0oNA6ByuY1ws4XVRhFHLewyn5KgoKqlq+n7O3sk2HU804leLm3Qmsa0WaLD0qmjgnbaRqnwepgdnp3X/wCU3FcQp90rb/VM/aBm7PCVt6l7jk/H2b8kJ/NPxWvn3RMt9AocIq53Zp3kDzKpaGnphzG7+307KrwanmuWcxydh2JU2+Mkj/aVtLFIusD+YW3azut8kcUxOTqjp7AtUxWq65db5lU2BRNsZXZj2KONkbbNaAPUVFJBO20jAVPgDf8ASkt8ijhWJRdQ+RWrYx/7nmtmYnL1ifzKiwD4svkqfDqWn6rN/b+CvhjeLOaCpMKoXf6S2JQdw+aZhVCz/SCbGxg5rQPWFrT0haGLuN8kGtHQP+289TiT6+WCnc3mi+9UoxcTDTuZk99lpGDpePNXTXtd0OBRkYOlwRkaOlwCqXyavJoSM/uUTn6FhkIvbemva4XBBWkYDbML8lbU1+v6CncBzL71reKUksWs5TG423IuDek2WYWvfctKzdzxvRNt5Ka9ruqQfog4H3rO3dzgi4D3oyNabFwCxOpkgijLPfIAi8NaCSAqiXLTSyMI3N3LD6ozUsLnvGdwVRUysxCliB5r73Re1vS4D6q6bI13Q4HkMjQbZhfsVfWmlZHa13PAQ3qqqqyWrNNTWGUXc4qjq6plVqtVa9rtcEHAjcVpG2vmFlpG5S64sqCsNVEXmw5x3KKeo1+SJ5BjtdvyRe0dLgtKy18wt23QKD2u6HAp0jW9LgFdYtUVEAg0JAc91lkx7vxoOsBmIvbemvDhuIKMjQbZhdFwHSVnba+YW7UJGHocFXTTtdBHEQC5293YFXVRpaZ0gsSny1L30hjLcjuus7W9LgFnb05gswAvdF4aN5AQN94KEjL2zC/Z6iU1gxeo1YAuyjpVG/FDL/iGNDLKloY6p1e6Qu5sjsu9GqkZg7BnNzJkzfJaajglp30srs2bnjtT6QVeLzsc4hoAO5RUrK6pqdIXZIrMaLqJro8PxNpcea9VdQNFQQyPLYyy71RzwR4gxlK8mN7d4Pav8O587al72VGc2d7lT3EMd3ZjbrdqrXVLcXBgYHP0fQg6rr6tkFRZmjOYtWIzwvxDRVDyImt6B7yqOdl66GJ5MWicW/LcmUTNlGpLnaQbwbqWSSqOH05cbPZmf802LUMShjjJ0co6Fhd9Vrv73rnDCqecdMUt/wBVLLrGJ04aebHHnQmo59PJUyu0hJyfJOndNhlPc3LZwLqvZBrIdVT/AGeTmsVFIzQYkyNxMWXm3UWHtGF6zmIkAzBaQy1mFPPvYnzUk9VUGrkduNmBRzzPwqdrHF2R/T78qoBRuqIHU0xYfvsd95Sv0cUj+60lCSjkgfJLM7WDcj5KqtU0NDK/rZ8hUUbYo2sb0BVlHU6yaikkGe3OaqOue+p0NVCGy23FQT6pDiEV/wCGeb+anjdDR0OlzaI75LfNUUNNJrAhnvC5v8P3hU1qbC552Xzk5UZKOKGOSGZ2sAgn5qojFXiVO1xIa6G5VNQRy1dXA5ztHH1RdazIzCLZz/FLL/Jaaiglp30srs2azx2qsMG0JhWZ8tvsz2LDW5aZo02kF9xWO5wKTJ1tJuQfjtxeNlliEOnxWniJIBZvVP8A4Ktq42E5BFmshJRyQSSSzO1g3I+SqJJKqjw+7t7n2JU9KI5KWhY92R5LnJtI2lxenawnI5pNkJqOeSd9VK4Ozcwdic7WMGJeSTFJYFPibDPhTWXso6YYhVVbpXGzHZW/JMzNwmuBO8SrEb7Lpd/vYsRnhfiGiqHkRMb0DtVDPz6yGmeXMyExqn1V4ZaZ0VSHby5Do9OZ9TTYpNMylfIC0DcqfEaqWVrHUL2A/eWHRSMFfmYRmkdZNoZ34XYM57ZS4ApslRUPhYyk0Vj9o4hU8UgxaqeWnKWixRNTRVlQY4TKyTfu9xVM2aWgxLm88v6FPTTNjop2xZjG2zmfJUxqJ6sPbBoomt946SpzOWSQz0Zkkucj7KhifDSRMf0hqMUm2RJkOXRdKxOnlbNDVQNJe084D3hVLJIqxtWKcyMeznN94UAqZRVyGHIwxkMZbf0JkMuxDHkOfKeb70+CoiZQVDIyXRss5nvUWnra+Od0RZHGN1+1MdVUmtwCmc7SOOU/VUNM92FGGRtic3SsEpZGMmfM0hx5ov2BMEtFpoTRmS5JjcFNT1RoIA5t36UEgDoU7Hw4g+V9MZWloy/JU8dSdoF8BbnZuCjkrdQFHqr8x3ZvdZGlfHV4cA0lrGWJVpKKpnvSmVjzdpCYzEBQveBaQuvlt7lkdVVdO5lGYi03e5SMzxvYfeCFGZ6aJ1PqRc/7j7KsgqRh9NduZ7HhzgFDLpYmuylt/cVMKqirpJ2RGSOTpA9yhFRWVzKh8BjYwbr+9YpTF2JQBv8ArdP5LEDURmF0bM8Q67FQwOfWyTsgMMeS1j71BBNJRVFIYnBwNwT0ISVL42QNo8sm7M+25aGQYtC7Kcoitm9yoontxCucWmzrWPamUU78NcMlntmLgD70JKiofCyOk0Vjz3EKqknZPK2amM0Tupu6Fg8EkNO7O3LmfcN7FjLZSKZ0cZfkkvYLa1Z/6dInMlfidLLoyBot/wAloHvxSou05HQ2umGopoXU+p5n78j7KanqMmH5m3cH3db3LE4pRLT1EQzOj+72hMnmnxendJEY+abApgloXzMNIZQ512EBPp6o4S8Pb9oTfKEdLPLhr9C8ZDYq9RQVNQWwOkZKbi3aqSKWowytbbnmQqeSrnpoIRSvGQtzH6KsikgrtZEOlY5tnBUorJTUShmiBH2Ysp9NUxNidRHT3/iKIZY2tv0D1s1BVioklpZg3P1gVQ0mqxZc13E3cfn7dBQTCsM80ua18g7PYa+idUaN8b8skZ3FUlDOJ9YqZQ99rC3QPRoaR1MJbkHNIXf9mdv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vCtv4l328K2/iXfbwrb+Jd9vD/8AZ42CsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrBWCsFYKwVgrD2nD6SGpc8SS5LDzWxqLxR8wtjUXij5hbGovFHzC2NReKPmFsai8UfMLY1F4o+YWxqLxR8wtjUXij5hbGovFHzC2NReKPmFsai8UfMLY1F4o+YWxqLxR8wtjUXij5hbGovFHzC2NReKPmFsai8UfMLY1F4o+YWxqLxR8wtjUXij5hbGovFHzC2NReKPmFXU0dPNkZJnFv6h/8QALRAAAgECBAUEAgIDAQAAAAAAAAERITEQQVFhMHHB8PEgQIGRUKGx0WBw4bD/2gAIAQEAAT8h/wBuzhOE4TjKxnGUSvwM4yTjOMDeRuLhRmVkvhkywzP0XDHQ0wVzMYn+AWEYLCMHbDTpQSHrkLMB3fAzIIIwgZ8YtEYV9CK/giWEEYxjDJMvKfBB6C/w2RIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEiRIkSJEv/OJ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnQ7E6HYnT/Wjgn+kG3+kGuSt/g9kVv8I7P8HvflxR9jvlj2U/B+ERwTccy4NT7GOiuQL8Iz6GTxn7KCkFcz8NKJ1D4zsO4f2GghYX4e8Ii4tg7+wYqGb+JETji2+wlIKxSF+IeAycRcwt4rRgkf4pPLBE5XDu8dM4YYvxTJgyOHQ+GbiQC/43KEibTkl4Rq8L3w1JIxpZO59+rArimpQsi4obVcKSdAlLRA47VC9hlrmVcTxM3CdR6pGgeqURguoLVJsyHryF7BNkripma7+yWGkPiRIhIcFYGSYSJDHYbc+Am0JOZqDVvRDbYtAgXFWJfsJPaKDQEu/Dz1hbC8hm79WwbBsENZH8XeiRC4mLFI1PEaIbkNrYhL2y0HFtwpqnBSUxqHHpT8hGYk5CCEQiEW2ntinKSfyGegZB6gVOGuy4w5gXuEoNfYZYJd7+tuDJWMN2NcQsuBDI+kJPVTHA8KWxY1BPBIG0CZqCPdmkxiqsG3C/QQg3kxdcK4JlR1FOohFgvrgxKoZT9TcGgNt3Y4IT3rM5YMsEvngtBj7YJN2IKvhqzdU8x+tSeANGQWxyH6F4oZUxEn4DOWLFclYMsEpvxIWlzqlXP1wpKrGjDEpXHu2Od+DIdrjUYpNuEJThske0pqqzZELZCWsX8XDnqsLDZ3wRuiQnm/Cv8uHK+o3cF/b0qKVzmh/c6fSJLoVxOE2O3MYoNpRahDNma4easXuI/Cog3LnDOfAY0lNkOjMfyEFeS+Cx/ksHVQhy/sY3GkvUk6bu38BcT+VcJokbYRuPcNJglcWdxji474aMgSRk+1zIMtDLk4SWGocYSr27kQWcDuaiTMTsxNcKKkZ7Bo+HFw6NE1fJ0MrmWY68LPxhcaGvDyASsTrCSaom5iT0TQwnlgrSxdnmTzJ5kcfVE1mKjWKE9HVSJH9p5cvleg33LFku0h/CLD9ixnIv45r0vSxumzzJ5kf/AHREbFkZMLCIuBI1ZjN6EaATrglcVozTMgwTazEkWtFC5fCI4TA7Tri2li5Dv9JLDpDJTz9EIGo7SydvjkLGTA2YrOfSEzhEp4/vr0fvMozhFD0PWGvMa5DJtzEDUEsvZNYRAr65T2JSoeWO+WO6sjlQTjKGsvmwNE31ty46feDJSf8ABiJTCyUk8CXjkhbEtREHWwpJKKi1msUXBuL6uKZY9EpSXPHtAkhqHAnDnCeQN+ZLwTMhi4iJe3blVGmRGFCeNN6yp4Oeee8Jlrzgp5zIOxtonrmU1wsBNLngr0eRQuDFz+hJ5DYkJF7ulmOuCQmLlwvR5086eVG+Scin0KreeU6Fdf5juzB2ZiW2P/xPIRk8rB6V6C1KGtmjc8sJUTVOCBkTSsRoncaJ8CkrF8mXkbobpbpNdgsIWuC0nCRAjMS++PGFZX0IsqUI8SeJPGifNKZx6O864uPPKCVaVl1FhTPCbVmai6wgnuYVDWGJ6PBM0pwXuK5yxvNdG+N8br6Fal0wrLYNCi9+9lgvEvYWSzKktrYAzpLYmgNCsFUPAnyczvghjn6KMzbMGMa6HDorGd1V/A/+AeAH/wAATFBYWFDYvwE2Fav0ImrTPKnlTyp5ERsgV2vTaLcmXzXL6Hd1U18GSt4OE24qXwWF5EtTWQsNV6qM8IFEYKIMY2bkWSyVvjGC6Hljyx5Y89iteDU+7lEGY9UaZImThY+OiviKhPysJKVaeQyJQnXUaQ6z/EPGMS49JcabWSNG+2ixTSanJs88PPDywU6/mD/W9G9DZJhI/ZShqzGLXQbaD1iTP1Iam8b435jSsayPGnjTxp4UaDrpZum+b5vm6MdvIkPGiRRUOFxzC6kZ3LdtXwEzVS0H5Xdma2TvgetUtbYIhp374e+b42+kweFPCnjTxpOSyjCVQ9SXmJYtaECCeFoxhm0T1N43iWpuG4bxuG4T1Oc5znOc5znOc5znOc5znOc5znOc5znOc5znOc5jnOc5znOc5znOc5znOc5znOc5znOc5zmOY5yepPUnqb2AlZijoNnXsWi7Q1ZH8k8T+TQmlXyRHHuoKck96CcibOeDJDmatk+qoSbn6E2vGzKLVtBIpb0z4Rc3tUitEbsjqkyF+oMVL8oSUHVP2rRv0TDe+wdueSRd86FWrBkZpbhX3nIfPE9/XI3dHysHhfBa+ykT9hA89ZDiw+SyV/ZUjUFq6CNDyKoujzXpkY1lm2LTbi9D68R/RXR+YDuWWshxIp+is+L/ALlJ2nJkQH+f2K8SzPQSTi4DvBz4YXFp6jhbkgSdNtXHMq+2VrlJ3aLcQRbHvQTxyavX2mcVSZ+hBS95D92w2cFPSWE4MOkCirMzf9iKWZYVXwTeb1FIK9of16IzZCz9cLubNhrZ79WSYNygkhQrN0RlatooCtgMKbGG1LhpiBonUgeyRKbWfwCCXzC4c+juJln/AAn2lOrF3X7pQimhcwxvLsB9fisTOw/gUoIVY5obtgwSgx0k+ynqWzBpgOK3k4w3JiZlFhX2iWgdE6fYhrAMiR9EDlMpOsNkTqvyijFtnIQtKU6jNDXe0F/Iny+Wa2e6SHEaAecxT4QxXrSG6qPvlfQ/M6lS+UfRVcWUa+ow/eQeSlEdsFZG19CPNvJxAQ2Vn0BGe9Vs+VK6BrQuTeCae7k0LOijbgJ1Ci2vm/DP2oqP2iGm9TorOwRf2RoJmkn/AJ8w5rNf8slxJl/YhScsxpptAp/Nc/usIN9VjLXv0oHHUCpfKFaTd/RlJA54ePMLQzEfT+gbJ9kkCrrv0okG0uwszWh377ULB9ajSltLC+xM9hQnKXtKmY7DepHcqUUrbFVkDPfR+9cja6wWQubQJhc+Q4uuy6kfIWmHLNKyw6yokR3apchHYJ2pE2aWyokYn8iLua1kURbKClECCkrVGSM5Ht/tDQqktZUOgrDmf0jN5F/zDNij+DhvW6LsYyOPJUXyyB24sKo5GvQgr9UQxvNpXWuRFGtbDLEfVBXZLRysAR1irMERJUUCXensoSnrm/CECbEr4QlsRg0oI8mfOPEHrdpas/j2jpyYaBHV0EoI9EEGLeuZOOidIogwtWmC1DWGM9eoaSM3jeELfJh8gz39bRqGOPhFhy+2CgoKpBhI1rhVkG2kchYWExZZL1wc2AzHZZC8LSthumJWm42n8JiGvdqyPXHvIIM3dEnKrlQaf7BAQ6NakcQbKOIgoPmeGFkUtlxI/wBVqdkkM+91B25rFUNQ2ajrw5JGHGrIusWlwTSOVzpO4tSbb5SQhmqcjma2ylSVGUNKaLXcLpUmrcCbEr1KxVSrYpVRKNBJZiCUmrSIm0ri5zBatyATRTYRG52TcDN0m/5MkhmbcDWCb210VyUNZ/QkclfSR1atKC3qSdOvDnCS15JVGQrVbknmMklNNajBTwbZO/BIENapyVdIzmhSjkTcp0J6CKGiFGhTV+jGNBTNn8PiCVSmoJ5R14aZBbVLgUsxN3xhSoUrrawkizVOREdbZN1LCLSWJ8PPKEDPm0OSvTVZAgJCEk9yEqE61pkOMnTtLgoOgV62GkZEnnJNFGrcCVhNaqoxG/crwHtXNsIPnQtRxdSlY5dSGExqJWJ8GBOmkgV3WEFRJWRmMiHBMkFsnq7QyDRZIRWCjmGhGlqWj9jPZC0I+PcEHyF+AWqPWD1arJIFKy8ewVJfpu5hoZntuhVpcz4CpA+/yP0eCKYXIYnPFQxlKUULczrQYQpLSEFJ0Zsk7Gdp7Ym6UPmkZkaykioZhVFR40BSTnczXkRU+3Vk5EgUcKXIrPiBaEr90NZ1Ne9FEy70GsBJucnqj8p3JxsGvMIciUnGUk5H80ylUN6wjJPgYml5lJRkgsKSJkemhSLrjP6KSQOkU4lCS8j2c1Skn75mvIiZhRITcjM1cZECORnMDd9ZImlEQ7J2TIFjOb6opZc045hX1cOfoZGigR5uMRVJKunAiNBK6G9C160+DGQc6KrOi/RWolNXTkRHUsq9Rh+C9F0EZa6GjsNDn/aiAbu33katVtqolQZqBR/YchrjY0qamkkYQQBAAygwFxVBN/TDULLr0yBWH3G9sKm2yuxaUXSE1IZE5wKWCim+ppy20nYSX+gpkh8x5oqchqCIg1jDvQoVEOlM+TD0FG4+qfEUsneoEPFPvFAz6FtIkoeZQNmP9DGcROchSt1nGHOHrMkOghIkvOMx0KVdDsIbXGObtvyoz+toy0syrY20LoETzqKgSNkLheYn9SZK/n0F3AOZBkmkoPLf8GN+FGasN5SsulVA5braIkq5kHYrambkSF05zs0ERZZ2gYNJLL5FL6YkQptQhdGoq0Ie0iT7xSamjdQy39shAoVKlpoSrgX1SIk1UThC5j3UmhN8uFBCx8PK2/NdYhEYRjBCwhEYQsIRC9MEEYQRi0W900jIWMeiCPVBA+r+OsM9AfYehijjIjR/6Z8ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx48ePHjx7/08dg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DYNg2DY9zTcqFSZc/bwwwwwwwwwwwwwwwwwwwwww2uy502p/kP/8QALBABAAIBAwMDBAIDAQEBAAAAAQARITFRYRBBcSAwgUBQkaFg8dHh8HCwsf/aAAgBAQABPxD/ANcsWoggjEEEYBenAWCPTk60gj05oJ3+woIInStL1LU8OrAcHoILbSbnsgHxiZCCjZjRmZE3gtNpol1TtGsJvHSWxMYDFQCbo6MFidsaEZPr7LR0hq4w2MQC7iym0S5QNe0G6mpBplRAT2vd3lQs84VjRSEC2X2K1RV2MKGGKW7lNIsti2CxnmA4o6CowBodEpUBu2MEIwZb7Cwh3xGWoi6eWBSsRRlr+IFBEslTpcADqUMVUCVOaVED2v8ADeEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJOEnCThJwk4ScJ/8ASEZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyZMmTJkyqO7/CF+b+EfmIafwhGn/h8yjpfwd34VNP+DuCsbV92WpMJj6BlmOXiPorCDjV9kdc1MkAn39EX55WnH0NDuJT38/ZNEuYBPe0M/amZdj6By3EHxfZkatSbtHva0zSGXffWiIGhcEg+zJZNAg0n3dWYLzFQ9+hVyykuZftFtu5mZu47e7g/EdWZfP3kMyH5gfaACJExb2Tz3uYeCM1fPuiViM9jSZZ1ftTUDJGNvDDJPb/V6ZD593KHmeKIAK+1CxIwqxcpz9v8R0WR7h0mspXKys37/bPiIYHaUSe1fsB7vcp0jn4Jk5g+vRqs7kay+T3boYmwSoHRg37LyOjfF7SAl+NCKDuwxPoISg176XGvRjJVUFjD7mEJpL0iCnPqpvO4EH2ShLv0ROyaKB2DBO8v1VC2e/S218e8B3i0cGG2/ogFmHswZlJpDL9q5GO67MQIMo9EGrLsuaMmoOWuqvpvpoizeEFoLCCx1Bogq5YpQYnY90/X4hqiRpGj6Q1xO5DmVJiwR09r4bpZswSgt6iVx1B7CzYcN/ObHXKZgTS8MS+gwQ2NTfUdNyyex0znV9wq1irPzjWephRR9M/sxGM6dmYbIlkXskZl3sej0BcAs21O6XDoB2nFOCcExt3lwS58+eTO0XVTVn0vqpnY1hAB7ShCkVw9lW5XQZ2gAr6hQMYJCVqYjCDNV6iFsRX8su7by9BFBYrl1xA8RR6xquknGYK0rqjpGVyiU5x0sEG1dPch61geWYwwlQCwq3L9WYiRlDEJgrJvAhHHocK0RPDXRrK5wINp7KSOX/kbg40J8CvTUzNUxDJjfolWOZf2n1FksDTOKrYxvFhvNCfWgSmKX+Gd4vamIcQIxAr1ASAZh0ysAPaZiWjm8Eye3ckDT1k0kezO4kFEiDdnqzv9u0Vy0bTvGqaIMAr69plmOIjTiGpMKrN4uJxMxKjASnuC1kMLuon4+ySFY8xEaYNRW3mWZoTF6Yq65YWtBNHU2gBg+xKWoVInxM9DQQUBn20Aq0Ev72AVDsTBfYDZ0JUE1SbuT7darM0USCoTtNbX0VIDBS/si95cADoBUAhi3V9gDCWpD9y+DXPl2t3qZeAX5x1L/uD9TZv3uqJSw01u20rtwiVM7/2Nft9rz1wzTeDY+ymix2XTs3j2Z4l8awTLb8FCakndocUbyYH+DSUaVLhloJsh/JGL+o+J4E3UFgSFmv7VhmJfWXTLtH6gdyDBu/u4f26Uz2IKA9+jlDokVmifsYhd9uztDrBKdKbyeyiI7KCiMM7+nAIhE1fhpNAAnbamnw419i0Y5V7sBIGrAJWe/wBB8z6yLYEqossG04WCJ5jWrt7S8D2nE8YzQe7ZOF7SDALjfMsaia83ArCoDQSJMJ6Mc0OiXdDogYUHo9E5zJhyzZ2FlCda2SkzGEBGx9BsGhBHR6gP1xbI3Wo3Pe1JYFMZKRvN90+nsf0JOt5p0nwnOsFj9k7QuCp7ewgmoCA7zPTMG4oSosTRwPcNYXkncaM1Lo0ZE5yF3CLtIVSurKbJSulfhej5gHh+lSoSTmiqi9BA2ZPQAQaI9Mej1bEgfF3wiMVcq+XoWAu7Ea88d8RqEg7j6zZRrKeibRgnUGsYiNAFj3BU1CV8D5YrVpkwXAPoQY/PeaPkiBzZM9ajYywMdMmP1hP61HbfmLNIt2JOjJL1ejLfaud3Q5tRuLSQR3RoNzoGk71OqxS0+I3og2jURsyQDVXQh1ymLWEt2veB5mpORkb6BiO8G/o2tZUtlM3wxG2MYNjEgoVnaAmpOKWqy5W1aaxohA0QD6e9lNVfxFKnXpU9z7q5lW7Ph0MjZRTAENWQfEKFwhM8B8QlICaBSXDvBRboQSzdVd/s5LZ6EaLlCpU1zLuwTT6tHERWXdgKhKJx1MeAV9AIAPNcmoWGOtlF+jvMTtuWjcRGWPvJqysePRKMS0UUersAgmEyQ6pZX+XQUC9FL8kNAaGlLeBmOnms5OpSKAbGPX7Wt4rGroFoNGVGpMLquDAAQ+tdDfpUeYGCHQJDV6GIVrmMTSDB65daX+fnUykxhIz4jR0s8Y2E7Jroa8cmkyCdqRNIIj0KORomEnd8L69RaijL+vZ/Xst/zo/hOn8K6hFn1+Dmjcs8T22I48qZVgsRM71q12NImfrmJ0uW0ExbIm6uHdjulNzHUVcTAuGGmgW64ayij5JrtPUKi9uhZ/oKP+vT/W0fNhrQHQWiClzFSOzHYfr7AbHTJehO6atov0DGP+lxet0mwfSCF/NUwUNfKjKBiN1O78OmZ2nfSkc7nEsiUkdpMlbh1eBOGw5mcDNdRl8we/1jrWUN2Un9En9En9Eh/qks6UdK9uPq0O8RaISO6Jp7prOerM/A9IH01Ilq5/8AN0e/6fzjriMbhfmMl1q+9iOfcItcp2l8s/MuOfygWsdQME3/AFNyDQL0ZYIc7CD95dZeOmr0HFFQbyiHcBNCSWfQu5NSEB3nYqJ0hWyOofWuqgUv7JxIBSIHtxCf1+f1+f1+f0+ZOnwCoScCcCOwjBUrPls/rcS8DQQDMcW6ahwqmahCvtxBAEKUWM1VFJRArUT/ANklk2HFZqBWrPPOBFIS9oaif0uf0+f1+Ao/pwD3rs8Tllm2SpUqVxLRndE2zoG9pju5APtB3YRX/EmrObv6z/gT/genSj/oT/qdFasyOb755pXdPPDnnnl98888/oqrvnnl5vN5H36bzy2+X3y/o/8Alld888tvl988s88888888eWW3zyy/T+WPY6UxMAGk0ZQ6kXMP59+3oAoK3ZqPbAZR9u4e4XUTFc6bzCwbdNVs5eUgruUX7AYgETIgits3Ibgfv7BGELvnrtdSGByPuagbPXpNUpo/dlDhKWLdvbI4VXmJCh/aqPkHZJ9KUfb6WOrnjhxUmQhdmWoeZXKw2EsrqtSmE9BqCQSg4ky/Uki676seWL3roZ0rU6hcQjfC8oG8/kll/FIvuvW0ld71EpPJNEp7CS/QwfYMiCLrsqv/wDEWv8A3aPiQ7HWyaN1vMPLyKYWFysSIU4yVmXaFUP0gtR9GadLgBXAa3FXtVRRtt1Wb5grF82ML0b3TIA1ZqEbqEOltAgoxLtqfMhTMTwQfRvnz30NhKXsuSv74aLRE7T0aagLyQleDXZcK/5RqQouQ4DyJV17MhlQuuCLNicR+Ij/AJojTrrMlgO0MIWHcJhHut68Vej4ot1ld0R26i3FtfIkId63H/geyQeYcT8zZUOYAHU1eo8FxMDsgW2BoFRl4RuCf+p2FjXSHdUkXjQWJNgmeEU1YA3oYFxKVp3mVMDuzhImaYx08CXRyKizmmUpum3+SVNQvhaHQW1Pko+pwNFoql1b0Y1ULneGS/rnYncmzo0A75qz+oH3WHSw+jMmRppDCuaOT/lxoHULENeAGHBD5VtUS/tlDeFk5r/1zcs60dqQm7+IfgwOd2Qd8Zqh3vuxD8Ij0fwqJhb4toOD8GYbsl43KsSV6H9csWwZbzLbhMAXUXYYfj6FCBRXHNgve7Zh/tYEZ1chhHle4DY9M9t5oWbjkydagiF+YtyWLDPGE+FgOX9mLKM9wQUH0Vig67RCQi+99SJ3IZAu8uWuHZlOQtClAAP+nCOrORt8EFBRbUBUmzcKaSixsEGNiPKb7bHez2wyjxSe+Fago6rFiPo29+KHADuzEOrQzlhordRkHkfZFHSdsnnydSav9LpFSZpmjHmazWRte2uisKo1Ks4pWEUZlFYdv7aSdfd28WyCh/wC0nupqLfDHWOMF7aGJ2BW0PGhBIDabvOaRzs7T0GkbzZYNbZJudl5elc2ju5gErO6Rwf0CfuEwlS6JIVDvY5D8zAZRKJRHCy7f2CCUV0TXmwY5aXGQIZ9RDw2yTLPxpaanRoLB7eEH7IaP8SIM/cyyBGh1gTM9AAEpKhT6pIRhjv9J37fK62rg+jArqx7dyGg2ggerC9ojg/MQ2cBTF2HdqX+RiYoAhTtzwtWnEscXGN+NLG+5co9T8BEpGZKHN68FTt6GFffMxiaphMC9lcjmZSa5a4p0RxDR66Szt7Vo+GXq7JoXlWySiBgxjbnxpZQCt/W+vrSJwVwmGptdWzkJ1xc0N4MF3Yor2U6KgfgMTJA4BtACUe8qV/K2X97qLOiRVQQBEHYPUBnaUqiJVxYBoGjzUcGPDSZYSz9Uw8Fy/6a4UgQhSSc0ypmgQ/JAOmpkvAwVEnyKAiW0VXhY7L9RD8sxqS7hp5hbT3K8JqUGTQThd4H6gE9VRGq3g4hbpUZG0RblQUF8TSgEafAy2eQl54M+BYhfzCvM9LAihCLILKYhnwwTKwWjdQbeLlRola0cVMnjEGj8QWBUDUIvBKBvF9wsDXjIGxiFkIgXr7EMaE3YD9SigpTXT5jadIRw5IXpQvo0wXdXbkqGyyAIbxAZdoyDtcAmkWI2MSaXg4eamuNwDt4uVxAlYqMeDcwl9EAji2BkMvidmdUh+poCCKL4lc37VAuK1CWgordnj4natqiel4NeRFFk0oVVHOdQBu1S1iwJ2fma8UpUpbMrB1SANxb3pEL+YdT9EA+Eisx1BR8Q9TK3szwzOQejcCBAKBcQt0egYTm8oXVbiH8moQCPTMuFxRJgXl5UVC3BO+yCK3lBQzCXLZCza9wC7G6OGiaYYYnTL6dkOC9WSC/gx1oVkaJCw0XGarDppNs4ZxG5E11YD16374sypm6skfDeAdtRZRkuzDBfsgz3iK0svWUY+e4WEqTH423SIDwShX2XZRyt7pglJfy90HuipIiQcidouD9AbRUbrBJwNTMEPCDiTdmNzECS7fROZBGsmJAAql0gIajUDXbYryn9jRiFlg3ia+QRdkShbrTVKYp/pSVfm8ruFLGSLFnGrEN4LSQQ0QT6iZMDEjVErA9NbYuHotPHhbsB8IsiY4bpokqXiEFZQBY71ni22QDql4QRrs6+0ilCzCqKbiS2VFNT6CLxKXlsxfI21l9aBFQJgb0ysnhd/KYeMlEJlST8ySafFBVWosRlKQQxBL5U1y5HuzvRUmR/wBYwk8hRjYublilaNhEGUhxZWyZt3iuEsWVbAzSau8xnpyNVCQ61nqjSeTpuCKfCqZ25PdxMPvNEVKWfg0SigDTC2kMnfXi9xDY9GqKVnr9+BZimfaJ3bBu7tL5gyw7ifuh7cnzES86RdyVJFrsNBHG4voqWhjmbMJerwV5iKoi0AgWLvXQz8VtjYPdk8symnMFLUII7GKVsBBd3Wrqw0vOlaYs79KIUZ6FIj/SZ5CtRZCYIKutAi3fWeKM4iYaX78tBiXS6usMJHvrMD2qjmhQ+HnL5IGwaBqMJGFP6rY+jvQmjTShCUi6uo7etlmiH+FCzc97VUzpaTRcMRLok1xgbTgd7F2k/EHvi0t7FFexRKlJkuswAhOetZ13IuE1FDalJUAdKJSAaHTglOil4lE4piqpUo26VEMpKbSiANCU6UQkaxDP65qrlnaUbSiUlSiVKQB2lSjbrRKShmBDoeuRcmipCBK6YR/7lXAhTKNpRKle9RK/+w9XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJIDcNuCbHb9PJJJJJJJJJJJJJJJJJJJJJIUOrcVb3P8hf/Z" alt="ERSE" style="width:36px;height:36px;border-radius:50%;object-fit:cover;"></div><div style="font-size:12px;font-weight:500;color:#1a2332;">Dir. académique</div><div style="font-size:10px;color:var(--muted);">ERSE Academy</div></div>
          <div style="text-align:center;"><div style="font-family:var(--font-display);font-size:15px;color:var(--gold);font-weight:600;margin-bottom:4px;">${c.date}</div><div style="font-size:12px;font-weight:500;color:#1a2332;">Date de délivrance</div><div style="font-size:10px;color:var(--muted);">Valide à vie</div></div>
        </div>
      </div>
      <div style="text-align:center;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
        <button class="btn-print" onclick="window.print()">🖨 Imprimer</button>
        <button class="btn-print" onclick="downloadCertBySubject('${c.subject}')" style="background:var(--gold-p);">⬇️ Télécharger</button>
      </div>
    </div>`).join('');
}

/* ═══════════════════════════════════════════
   PROFILE
═══════════════════════════════════════════ */
function renderProfile(){
  if(!currentUser)return;
  const u=currentUser;
  const big=document.getElementById('profile-avatar-big');
  big.textContent=u.initials;
  big.style.background=u.color+'33';
  big.style.color=u.color;
  document.getElementById('profile-fullname').textContent=u.name;
  document.getElementById('profile-sub').textContent=(u.spec?u.spec+' · ':'')+`Licence ${u.level} · ${u.email}`;
  const myCerts=DB.certificates.filter(c=>c.userId===u.email||c.userId===String(u.id)||c.studentName===u.name);
  const myPassed=DB.students.find(s=>s.id===u.id)?.passed||u.passed||0;
  // Afficher XP bar
  const xpEl=document.getElementById('profile-xp-bar');
  if(xpEl) xpEl.innerHTML=renderXPBar(u);
  document.getElementById('profile-stats').innerHTML=[
    {n:myPassed,l:'Examens réussis'},
    {n:myCerts.length,l:'Certificats'},
    {n:u.avgScore||0,l:'Score moyen %'},
  ].map(s=>`<div class="ps"><div class="ps-num">${s.n}</div><div class="ps-lbl">${s.l}</div></div>`).join('');
  const subjects=DB.subjects.filter(s=>s.level===u.level&&s.active).slice(0,5);
  document.getElementById('profile-progress').innerHTML=subjects.map(s=>{
    // Vérifier si un certificat existe pour cette matière
    const hasCert = myCerts.find(c=>c.subject===s.name);
    // Vérifier si un examen a été passé pour cette matière
    const subjectExams = DB.exams.filter(e=>parseInt(e.subjectId)===parseInt(s.id)||String(e.subjectId)===String(s.id));
    let done = 0;
    if(hasCert) done = 100;
    else if(subjectExams.length > 0 && myPassed > 0) done = Math.min(80, Math.round((myPassed / subjectExams.length) * 100));
    else done = 0;
    const color = done===100?'var(--gc)':done>50?'var(--gold)':'var(--b4)';
    return `<div class="progress-item"><div class="progress-label"><span>${s.icon} ${s.name}</span><span style="color:${color};font-weight:600;">${done}%${done===100?' ✅':''}</span></div><div class="progress-bar"><div class="progress-fill" style="width:${done}%;background:${color};"></div></div></div>`;
  }).join('');
  const activities=(u.activity&&u.activity.length?u.activity:[
    {text:'Connexion à la plateforme',ic:'🔐',bg:'#b0d4f4',time:new Date().toLocaleDateString('fr-FR')},
    {text:'Visite de la page EnergyBot',ic:'⚡',bg:'#F0C96A',time:new Date().toLocaleDateString('fr-FR')},
  ]).slice(0,5);
  document.getElementById('profile-activity').innerHTML=activities.map(a=>`
    <div class="activity-item">
      <div class="activity-ic" style="background:${a.bg};">${a.ic}</div>
      <div style="flex:1;font-size:13px;">${a.text}</div>
      <div style="font-size:11px;color:var(--muted);">${a.time}</div>
    </div>`).join('');
  // Badges
  const badgesSection=document.createElement('div');
  badgesSection.innerHTML=renderBadgesSection(currentUser);
  const profileBody=document.querySelector('.profile-body');
  const existingBadges=document.getElementById('badges-section');
  if(existingBadges) existingBadges.remove();
  if(profileBody){
    const div=document.createElement('div');
    div.id='badges-section';
    div.style.gridColumn='1 / -1';
    div.innerHTML=renderBadgesSection(currentUser);
    profileBody.appendChild(div);
  }
  // Vérifier nouveaux badges
  checkAndNotifyBadges(currentUser);
  document.getElementById('profile-certs-mini').innerHTML=myCerts.length?myCerts.map(c=>`
    <div style="display:flex;align-items:center;gap:8px;padding:.5rem 0;border-bottom:1px solid var(--border);">
      <span style="font-size:18px;">🎓</span>
      <div><div style="font-size:13px;font-weight:500;">${c.subject}</div><div style="font-size:11px;color:var(--muted);">${c.date} · ${c.score}%</div></div>
    </div>`).join(''):'<div style="color:var(--muted);font-size:13px;padding:.5rem 0;">Aucun certificat pour l\'instant.</div>';
}

/* ═══════════════════════════════════════════
   NOTIFICATIONS
═══════════════════════════════════════════ */
function toggleNotifPanel(){
  const panel=document.getElementById('notif-panel');
  panel.classList.toggle('open');
  renderNotifs();
}
function renderNotifs(){
  const list=document.getElementById('notif-list');
  if(!DB.notifications.length){list.innerHTML='<div class="notif-empty">Aucune notification</div>';return;}
  list.innerHTML=DB.notifications.map(n=>`
    <div class="notif-item ${n.unread?'unread':''}" onclick="markRead(${n.id})">
      <div class="notif-item-ic" style="background:${n.bg||'#b0d4f4'};">${n.ic}</div>
      <div class="notif-item-txt">
        <div class="notif-item-title">${n.title}</div>
        <div class="notif-item-sub">${n.sub} · ${n.time}</div>
      </div>
      ${n.unread?'<div class="notif-unread-dot"></div>':''}
    </div>`).join('');
  updateNotifDot();
}
function markRead(id){
  const n=DB.notifications.find(x=>x.id===id);
  if(!n) return;
  n.unread=false;
  saveData();
  renderNotifs();
  // Rediriger selon le type de notification
  const title=(n.title||'').toLowerCase();
  const sub=(n.sub||'').toLowerCase();
  if(title.includes('examen') || sub.includes('examen') || n.ic==='📝'){
    toggleNotifPanel(); goPage('exams');
  } else if(title.includes('certificat') || n.ic==='🎓'){
    toggleNotifPanel(); goPage('certs');
  } else if(title.includes('discussion') || title.includes('forum') || n.ic==='💬'){
    toggleNotifPanel(); goPage('forum');
  } else if(title.includes('matière') || title.includes('cours') || n.ic==='📚'){
    toggleNotifPanel(); goPage('courses');
  } else if(title.includes('administration') || n.ic==='📣'){
    toggleNotifPanel();
  } else {
    toggleNotifPanel();
  }
}
function clearNotifs(){
  DB.notifications=[];
  saveData();
  renderNotifs();
  updateNotifDot();
  toast('Notifications effacées','ok');
}

function checkRevisionReminders(){
  if(!currentUser || currentUser.role==='admin') return;
  const results = DB.examResults || [];
  const userResults = results.filter(r=>r.userId===(currentUser.email||currentUser.id));
  if(!userResults.length) return;
  const now = Date.now();
  const DAYS_5 = 5 * 24 * 3600 * 1000;
  const DAYS_10 = 10 * 24 * 3600 * 1000;

  // Regrouper par matière — dernière date de révision
  const lastBySubject = {};
  userResults.forEach(r=>{
    if(!r.subjectName || !r.date) return;
    const t = new Date(r.date).getTime();
    if(!lastBySubject[r.subjectName] || t > lastBySubject[r.subjectName]) {
      lastBySubject[r.subjectName] = t;
    }
  });

  // Envoyer rappels
  const reminders = [];
  Object.entries(lastBySubject).forEach(([subj, last])=>{
    const diff = now - last;
    if(diff >= DAYS_10){
      reminders.push({subj, days: Math.floor(diff/86400000), urgent: true});
    } else if(diff >= DAYS_5){
      reminders.push({subj, days: Math.floor(diff/86400000), urgent: false});
    }
  });

  // Max 2 rappels par session pour ne pas spammer
  reminders.slice(0,2).forEach(r=>{
    setTimeout(()=>{
      pushNotif(
        r.urgent ? '⚠️ Révision urgente !' : '📚 Rappel de révision',
        (r.urgent ? 'Plus de ' : '') + r.days + ' jours sans réviser ' + r.subj + '. Reprends là où tu t\'es arrêté !',
        r.urgent ? '⚠️' : '📚',
        r.urgent ? '#FAEEDA' : '#b0d4f4'
      );
    }, (reminders.indexOf(r)+1) * 3000);
  });
}
function initPlanning(){
  if(currentUser){
    const sel = document.getElementById('plan-level');
    if(sel){
      sel.value = currentUser.level || 1;
      renderPlanSubjects(currentUser.level||1);
    }
  }
  const minDate = new Date();
  minDate.setDate(minDate.getDate()+2);
  const inp = document.getElementById('plan-date');
  if(inp) inp.min = minDate.toISOString().split('T')[0];
  // Recharger les matières quand le niveau change
  const lvlSel = document.getElementById('plan-level');
  if(lvlSel) lvlSel.onchange = function(){ renderPlanSubjects(parseInt(this.value)); };
}

function renderPlanSubjects(level){
  const container = document.getElementById('plan-subjects-list');
  if(!container) return;
  const subjects = DB.subjects.filter(s=>s.active && s.level===level);
  container.innerHTML = subjects.map(s=>`
    <label style="display:flex;align-items:center;gap:5px;padding:5px 10px;border:1px solid var(--border);border-radius:99px;cursor:pointer;font-size:12px;background:var(--b0);user-select:none;">
      <input type="checkbox" value="${s.id}" checked style="accent-color:var(--b6);cursor:pointer;">
      ${s.icon} ${s.name}
    </label>
  `).join('');
}

function generatePlanning(){
  const dateVal = document.getElementById('plan-date').value;
  const hours = parseInt(document.getElementById('plan-hours').value);
  const level = parseInt(document.getElementById('plan-level').value);

  if(!dateVal){ toast("Choisis une date d'examen",'err'); return; }
  const examDate = new Date(dateVal);
  const today = new Date(); today.setHours(0,0,0,0);
  const daysLeft = Math.floor((examDate - today) / 86400000);
  if(daysLeft < 2){ toast('Choisis une date dans au moins 2 jours','err'); return; }

  // Matières cochées par l'étudiant
  const checkedBoxes = document.querySelectorAll('#plan-subjects-list input[type=checkbox]:checked');
  const selectedIds = Array.from(checkedBoxes).map(cb=>cb.value);
  const allSubjects = DB.subjects.filter(s=>s.active && s.level===level);
  const subjects = selectedIds.length>0 ? allSubjects.filter(s=>selectedIds.includes(String(s.id))||selectedIds.includes(s.id)) : allSubjects;
  if(!subjects.length){ toast('Sélectionne au moins une matière','err'); return; }
  const breaks = parseInt(document.getElementById('plan-breaks').value)||1;
  const relaxMin = parseInt(document.getElementById('plan-relax').value)||30;

  const results = (DB.examResults||[]).filter(r=>r.userId===(currentUser?currentUser.email||currentUser.id:''));

  // Stats par matière
  const subjectStats = subjects.map(s=>{
    const examsForSubj = DB.exams.filter(e=>parseInt(e.subjectId)===parseInt(s.id)||e.subjectId===s.id);
    const subjResults = results.filter(r=>examsForSubj.some(e=>parseInt(e.id)===parseInt(r.examId)||e.id===r.examId));
    const avg = subjResults.length ? Math.round(subjResults.reduce((a,r)=>a+r.score,0)/subjResults.length) : 0;
    const attempts = subjResults.length;
    const lastExam = examsForSubj[0];
    const status = avg===0?'never':avg>=70?'ok':avg>=50?'warn':'danger';
    return Object.assign({},s,{avg, attempts, status, priority: avg===0?999:(100-avg), examId: lastExam?lastExam.id:null});
  }).sort((a,b)=>b.priority-a.priority);

  const never = subjectStats.filter(s=>s.status==='never').length;
  const danger = subjectStats.filter(s=>s.status==='danger').length;
  const ok = subjectStats.filter(s=>s.status==='ok').length;
  const warn = subjectStats.length - never - danger - ok;

  const slots = hours===1?['Matin']:hours===2?['Matin','Soir']:hours===3?['Matin','Apres-midi','Soir']:['Matin','Apres-midi','Soiree','Nuit'];
  const slotDuration = Math.floor(hours/slots.length);

  // Planning
  const plan = [];
  let subIdx = 0;
  for(let d=0; d<daysLeft; d++){
    const date = new Date(today);
    date.setDate(today.getDate()+d);
    const dayName = date.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    const isLastDay = d===daysLeft-1;
    const isWeekend = date.getDay()===0||date.getDay()===6;
    // Calculer les créneaux avec pauses et détentes
    const daySlots = [...slots];
    if(breaks>0) for(let b=0;b<breaks;b++) daySlots.splice(Math.floor(daySlots.length/2),0,'break');
    if(relaxMin>0) daySlots.push('relax');

    if(isLastDay){
      plan.push({date:dayName, type:'final', sessions:[
        {slot:'Matin', subj:'Revision generale', action:'Revoir toutes les notions difficiles', color:'#ef4444', icon:'🔁'},
        {slot:'Soir', subj:'Simulation examen', action:'Passer un examen en conditions reelles', color:'#ef4444', icon:'📝'}
      ]});
    } else {
      let studyIdx = 0;
      const sessions = daySlots.map(function(slot){
        if(slot==='break') return {slot:'☕ Pause', subj:'Repos', action:'Detends-toi, bois de l eau', color:'#64748b', icon:'☕', isBreak:true};
        if(slot==='relax') return {slot:'🎮 Detente', subj:relaxMin+'min de loisirs', action:'Musique, balade ou sport leger', color:'#8b5cf6', icon:'🎮', isRelax:true};
        const subj = subjectStats[(subIdx+studyIdx) % subjectStats.length];
        studyIdx++;
        const c = subj.status==='never'?'#8b5cf6':subj.status==='danger'?'#ef4444':subj.status==='warn'?'#f59e0b':'var(--gc)';
        return {slot:slot, subj:subj.name, icon:subj.icon, avg:subj.avg, status:subj.status, color:c, examId:subj.examId, duration:slotDuration+'h', attempts:subj.attempts};
      });
      plan.push({date:dayName, type:isWeekend?'weekend':'normal', sessions:sessions});
      subIdx += studyIdx;
    }
  }

  const statusLabel = {never:'Jamais revise', danger:'A risque', warn:'En progres', ok:'Maitrise'};
  const statusCol = {never:'#8b5cf6', danger:'#ef4444', warn:'#f59e0b', ok:'var(--gc)'};

  let html = '';

  // Recap matières
  html += '<div style="background:var(--card-bg);border:1px solid var(--border);border-radius:16px;padding:1.2rem;margin-bottom:1.2rem;">'
    +'<div style="font-size:13px;font-weight:600;color:var(--b8);margin-bottom:.8rem;">📊 Etat de tes matieres</div>'
    +'<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-bottom:.8rem;">'
    +'<div style="background:rgba(139,92,246,.1);border-radius:8px;padding:.5rem;text-align:center;"><div style="font-size:18px;font-weight:700;color:#8b5cf6;">'+never+'</div><div style="font-size:10px;color:var(--muted);">Jamais revise</div></div>'
    +'<div style="background:rgba(239,68,68,.1);border-radius:8px;padding:.5rem;text-align:center;"><div style="font-size:18px;font-weight:700;color:#ef4444;">'+danger+'</div><div style="font-size:10px;color:var(--muted);">A risque</div></div>'
    +'<div style="background:rgba(245,158,11,.1);border-radius:8px;padding:.5rem;text-align:center;"><div style="font-size:18px;font-weight:700;color:#f59e0b;">'+warn+'</div><div style="font-size:10px;color:var(--muted);">En progres</div></div>'
    +'<div style="background:rgba(16,185,129,.1);border-radius:8px;padding:.5rem;text-align:center;"><div style="font-size:18px;font-weight:700;color:var(--gc);">'+ok+'</div><div style="font-size:10px;color:var(--muted);">Maitrise</div></div>'
    +'</div>';

  html += subjectStats.map(function(s){
    const c = statusCol[s.status];
    return '<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);">'
      +'<span style="font-size:16px;">'+s.icon+'</span>'
      +'<div style="flex:1;">'
      +'<div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px;">'
      +'<span style="font-weight:500;color:var(--text);">'+s.name+'</span>'
      +'<span style="color:'+c+';font-weight:600;">'+s.avg+'%</span>'
      +'</div>'
      +'<div style="background:var(--border);border-radius:99px;height:5px;">'
      +'<div style="background:'+c+';width:'+s.avg+'%;height:5px;border-radius:99px;"></div>'
      +'</div>'
      +'<div style="font-size:10px;color:var(--muted);margin-top:2px;">'+statusLabel[s.status]+' · '+s.attempts+' examen'+(s.attempts>1?'s':'')+'</div>'
      +'</div>'
      +(s.examId?'<button onclick="startQuiz('+s.examId+');goPage(\'exams\')" style="font-size:10px;padding:4px 8px;border-radius:6px;border:1px solid var(--border);background:none;color:var(--b6);cursor:pointer;white-space:nowrap;font-family:var(--font-body);">&#9654; Reviser</button>':'')
      +'</div>';
  }).join('') + '</div>';

  // Compteur
  html += '<div style="display:flex;align-items:center;gap:10px;margin-bottom:1rem;padding:.8rem 1rem;background:var(--card-bg);border:1px solid var(--border);border-radius:12px;">'
    +'<div style="font-size:2rem;font-weight:800;color:var(--b6);">'+daysLeft+'</div>'
    +'<div><div style="font-size:13px;font-weight:600;color:var(--b8);">jour'+(daysLeft>1?'s':'')+' avant l\'examen</div>'
    +'<div style="font-size:11px;color:var(--muted);">'+hours+'h/jour · '+subjects.length+' matieres</div>'
    +'</div></div>';

  html += '<div style="font-size:13px;font-weight:600;color:var(--b8);margin-bottom:.8rem;">📋 Planning jour par jour</div>';

  html += plan.map(function(day,di){
    const isFinal = day.type==='final';
    const isWE = day.type==='weekend';
    const borderCol = isFinal?'#ef4444':isWE?'#8b5cf6':'var(--border)';
    const bgCol = isFinal?'rgba(239,68,68,0.05)':isWE?'rgba(139,92,246,0.05)':'var(--card-bg)';
    return '<div style="background:'+bgCol+';border:1px solid '+borderCol+';border-radius:14px;padding:1rem;margin-bottom:10px;">'
      +'<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.8rem;">'
      +'<div style="font-size:12px;font-weight:700;color:'+(isFinal?'#ef4444':isWE?'#8b5cf6':'var(--b8)')+';">'+day.date+' — J-'+(daysLeft-di)+'</div>'
      +(isFinal?'<span style="font-size:10px;padding:2px 8px;border-radius:99px;background:rgba(239,68,68,.15);color:#ef4444;">Jour final 🔥</span>':isWE?'<span style="font-size:10px;padding:2px 8px;border-radius:99px;background:rgba(139,92,246,.15);color:#8b5cf6;">Week-end 📖</span>':'')
      +'</div>'
      + day.sessions.map(function(sess){
        const hasBtnExam = sess.examId && !isFinal;
        return '<div style="display:flex;align-items:center;gap:10px;padding:.6rem;border-radius:9px;background:var(--b0);margin-bottom:6px;">'
          +'<div style="font-size:11px;color:var(--muted);min-width:65px;">'+sess.slot+'</div>'
          +'<div style="flex:1;">'
          +(sess.icon?'<span>'+sess.icon+'</span> ':'')
          +'<span style="font-size:12px;font-weight:500;color:var(--text);">'+sess.subj+'</span>'
          +(sess.avg>0?'<span style="font-size:10px;color:'+sess.color+';margin-left:6px;font-weight:600;">'+sess.avg+'%</span>':'')
          +(sess.action?'<div style="font-size:11px;color:var(--muted);margin-top:2px;">'+sess.action+'</div>':'')
          +(sess.duration?'<div style="font-size:10px;color:var(--muted);">⏱ '+sess.duration+'</div>':'')
          +'</div>'
          +(hasBtnExam?'<button onclick="startQuiz('+sess.examId+');goPage(\'exams\')" style="font-size:10px;padding:5px 10px;border-radius:7px;border:none;background:var(--b6);color:#fff;cursor:pointer;white-space:nowrap;font-family:var(--font-body);">&#9654; Lancer</button>':'')
          +'</div>';
      }).join('')
      +'</div>';
  }).join('');

  html += '<div style="font-size:11px;color:var(--muted);text-align:center;margin-top:.5rem;padding-bottom:1rem;">Matières prioritaires selon tes scores · Clique Lancer pour commencer</div>';

  document.getElementById('plan-result').innerHTML = html;
  const genBtn = document.getElementById('plan-gen-btn');
  if(genBtn) genBtn.style.display = 'block';
  toast('Planning generé !','ok');
}

